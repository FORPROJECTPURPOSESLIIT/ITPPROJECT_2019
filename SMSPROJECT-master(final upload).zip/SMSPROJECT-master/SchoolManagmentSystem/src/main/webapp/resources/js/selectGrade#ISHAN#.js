  var $select1 = $( '#select1' ),
	$select2 = $( '#select2' ),
$select3 = $( '#select3'),
$options = $select2.find( 'option' ),
$options1 = $select3.find( 'option' );

$select1.on( 'change', function() {
$select2.html( $options.filter( '[value="' + this.value + '"]' ) );
$select3.html( $options1.filter( '[value="' + this.value + '"]' ) );
} ).trigger( 'change' );
