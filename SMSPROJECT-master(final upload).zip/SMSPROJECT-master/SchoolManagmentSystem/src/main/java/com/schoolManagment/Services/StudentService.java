package com.schoolManagment.Services;

import java.util.List;

import com.schoolManagment.Model.Student;

public interface StudentService {

	public List<Student> ListAllStudents();
	
	public void AddStudent(Student student);
	
	public void UpdateStudent(Student student);
	
	public void DeleteStudent(int indexNo);
	
	public Student FindStudentById(int indexNo);
	
	
}
