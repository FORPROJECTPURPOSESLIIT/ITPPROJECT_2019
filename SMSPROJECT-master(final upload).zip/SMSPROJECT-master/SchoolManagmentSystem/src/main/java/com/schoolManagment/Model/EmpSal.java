package com.schoolManagment.Model;

public class EmpSal {

	private String empId;
	private Double 	salary;
	
	
	
	
	
	public EmpSal() {
		super();
	}

	public EmpSal(String empId) {
		super();
		this.empId = empId;
	}
	
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	
	
}
