package com.schoolManagment.Services;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mysql.cj.jdbc.Blob;
import com.schoolManagment.Controllers.ExaminationServlet;

import com.schoolManagment.Model.Student;

public class ExaminationServicesImpl implements ExaminationServiceInterface{

	private static Connection connection;

	private static Statement statement;

	private PreparedStatement preparedStatement;
	
	final Logger logger = LoggerFactory.getLogger(ExaminationServicesImpl.class);
	
	public ExaminationServicesImpl() {
		logger.info("invoked!!");
	}
	
	
	
	@Override
	public ArrayList<Student> getResults(Student student) {
		logger.info("in getResults");
		ArrayList<Student> studentList = new ArrayList<Student>();
		
		try {
			
			DBConnection connect = new DBConnection();
			connection = connect.getConnection();
			
			statement = connection.createStatement();
			
			String grade, subject;
			grade = student.getGrade();
			subject = student.getSubject();
			
			ResultSet resultset1 = statement.executeQuery("SELECT s.indexNo, s.cid, s.name, st.term1, st.term2, st.term3\r\n" + 
					"FROM student_subject st, student s\r\n" + 
					"WHERE st.indexNo = s.indexNo AND s.cid = '"+ grade + "' AND st.sid = '"+ subject + "' ");
			
			while (resultset1.next()) {
				Student nStudent = new Student();
				
				nStudent.setIndexNo(resultset1.getInt(1));
				nStudent.setGrade(resultset1.getString(2));
				nStudent.setName(resultset1.getString(3));
				nStudent.setTerm1(resultset1.getString(4));
				nStudent.setTerm2(resultset1.getString(5));
				nStudent.setTerm3(resultset1.getString(6));
				studentList.add(nStudent);
				
				
				
			}
			
//			Student nStudent = new Student();
//			
//			nStudent.setIndexNo(9999);
//			nStudent.setGrade(grade);
//			studentList.add(nStudent);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return studentList;
		
	}

	@Override
	public ArrayList<Student> getIndividualResults(Student student) {
		logger.info("individual results");
		
		ArrayList<Student> studentList1 = new ArrayList<Student>();
		
		try {
			
			DBConnection connect = new DBConnection();
			connection = connect.getConnection();
			
			statement = connection.createStatement();
			
			int indexNo = student.getIndexNo();
			
			ResultSet resultset1 = statement.executeQuery("SELECT st.indexNo, st.sid, s.name, st.term1, st.term2, st.term3\r\n" + 
					"FROM student_subject st, student s\r\n" + 
					"WHERE st.indexNo = s.indexNo AND st.indexNo = '"+ indexNo + "' ");
			
			while (resultset1.next()) {
				Student nStudent = new Student();
				
				nStudent.setIndexNo(resultset1.getInt(1));
				nStudent.setSubject(resultset1.getString(2));
				nStudent.setName(resultset1.getString(3));
				nStudent.setTerm1(resultset1.getString(4));
				nStudent.setTerm2(resultset1.getString(5));
				nStudent.setTerm3(resultset1.getString(6));
				
				studentList1.add(nStudent);
		
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return studentList1;
		
	}


	@Override
	public void updateClassResults(Student student) {
		
		try {
			
			DBConnection connect = new DBConnection();
			connection = connect.getConnection();
			
			statement = connection.createStatement();
			
			String indexNo = Integer.toString(student.getIndexNo());
			String subject = student.getSubject();
			String term1 = student.getTerm1();
			String term2 = student.getTerm2();
			String term3 = student.getTerm3();
			
			int resultset1 = statement.executeUpdate("UPDATE student_subject \r\n" + 
					"SET term1='"+ term1 + "', term2='"+ term2 + "', term3='"+ term3 + "'\r\n" + 
					"WHERE indexNo="+ indexNo +" and sid='"+ subject + "' ");
			
			
			

			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void update2ndtermResults(Student student) {
		
		try {
			
			DBConnection connect = new DBConnection();
			connection = connect.getConnection();
			
			statement = connection.createStatement();
			
			String indexNo = Integer.toString(student.getIndexNo());
			String subject = student.getSubject();
			String grade = student.getGrade();
			
//			String term1 = student.getTerm1();
			String term2 = student.getTerm2();
//			String term3 = student.getTerm3();
			
			ResultSet resultset = statement.executeQuery("SELECT st.term1, st.term2 FROM student_subject st "
					+ "WHERE cid = '"+ grade + "' AND indexNo = '"+ indexNo + "'  AND sid = '"+ subject + "' ");
			
			
			if(!resultset.next()) {

				System.out.println("no data");
			    logger.info("no Data *********************************");
			   try {
					
					int indexNo_int = student.getIndexNo();
					
					
					String query = "INSERT INTO student_subject \r\n" + 
							"VALUES (?,?,?,?,?,?) ";
					
					PreparedStatement preparedStmt = connection.prepareStatement(query);
					preparedStmt.setInt(1, indexNo_int);
					preparedStmt.setString(2, grade);
					preparedStmt.setString(3, subject);
					preparedStmt.setString(4, "N/A");
					preparedStmt.setString(5, term2);
					preparedStmt.setString(6, "");
					
					preparedStmt.execute();
				      
				    connection.close();
					
					
				} catch (Exception e) {
					e.printStackTrace();
					ExaminationServlet.whereToGo = 5;
				}
			   
			   
			}else if(resultset.getString(2).matches("\\d+")){
				
				ExaminationServlet.whereToGo = 5;
				
			}else {
				System.out.println("result 2 is : " + resultset.getString(2));
				int resultset1 = statement.executeUpdate("UPDATE student_subject \r\n" + 
						"SET term2='"+ term2 + "' \r\n" + 
						"WHERE indexNo="+ indexNo +" and sid='"+ subject + "' ");
			} 
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void update3rdtermResults(Student student) {
		
try {
			
			DBConnection connect = new DBConnection();
			connection = connect.getConnection();
			
			statement = connection.createStatement();
			
			String indexNo = Integer.toString(student.getIndexNo());
			String subject = student.getSubject();
			String grade = student.getGrade();
			
//			String term1 = student.getTerm1();
//			String term2 = student.getTerm2();
			String term3 = student.getTerm3();
			
			ResultSet resultset = statement.executeQuery("SELECT st.term1, st.term2, st.term3 FROM student_subject st "
					+ "WHERE cid = '"+ grade + "' AND indexNo = '"+ indexNo + "'  AND sid = '"+ subject + "' ");
			
			
			if(!resultset.next()) {

				System.out.println("no data");
			    logger.info("no Data *********************************");
			   try {
					
					int indexNo_int = student.getIndexNo();
					

					String query = "INSERT INTO student_subject (indexNo, cid, sid, term1, term2, term3) \r\n" + 
							"VALUES (?,?,?,?,?,?) ";
					
					PreparedStatement preparedStmt = connection.prepareStatement(query);
					preparedStmt.setInt(1, indexNo_int);
					System.out.println("gradeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" + grade);
					preparedStmt.setString(2, grade);
					preparedStmt.setString(3, subject);
					preparedStmt.setString(4, "N/A");
					preparedStmt.setString(5, "N/A");
					preparedStmt.setString(6, term3);
					
					preparedStmt.execute();
				      
				    connection.close();
					
					
				} catch (Exception e) {
					e.printStackTrace();
					ExaminationServlet.whereToGo = 5;
				}
			   
			   
			}else if(resultset.getString(3).matches("\\d+")){
				System.out.println("im here................................................");
				ExaminationServlet.whereToGo = 5;
				
			}else {
				System.out.println(resultset.getString(3));
				int resultset1 = statement.executeUpdate("UPDATE student_subject \r\n" + 
						"SET term3='"+ term3 + "' \r\n" + 
						"WHERE indexNo="+ indexNo +" and sid='"+ subject + "' ");
			} 
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}


	@Override
	public void insertResults(Student student) {
		try {
			
			DBConnection connect = new DBConnection();
			connection = connect.getConnection();
			
			statement = connection.createStatement();
			
			System.out.println("Insert Result Func Called!");
			
			int indexNo = student.getIndexNo();
			String grade, subject;
			String term1 = student.getTerm1();
			grade = student.getGrade();
			subject = student.getSubject();
			
			ResultSet resultset = statement.executeQuery("SELECT st.term1, st.term2, st.term3 FROM student_subject st"
					+ " WHERE cid = '"+ grade + "' AND indexNo = '"+ indexNo + "'   AND sid = '"+ subject + "'  ");
			
			
			if(!resultset.next()) {
				
				String query = "INSERT INTO student_subject \r\n" + 
						"VALUES (?,?,?,?,?,?) ";
				
				PreparedStatement preparedStmt = connection.prepareStatement(query);
				preparedStmt.setInt(1, indexNo);
				preparedStmt.setString(2, grade);
				preparedStmt.setString(3, subject);
				preparedStmt.setString(4, term1);
				preparedStmt.setString(5, "");
				preparedStmt.setString(6, "");
				
				preparedStmt.execute();
			      
			    connection.close();
			}else if(resultset.getString(1).matches("\\d+")){
				
				ExaminationServlet.whereToGo = 5;
				
			}else{
				System.out.println(resultset.getString(1));
				int resultset1 = statement.executeUpdate("UPDATE student_subject \r\n" + 
						"SET term1='"+ term1 + "' \r\n" + 
						"WHERE indexNo="+ indexNo +" and sid='"+ subject + "' ");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			ExaminationServlet.whereToGo = 5;
		}
		
	}


	@Override
	public ArrayList<Student> getAllStudentResultList(Student student) {
		final Logger logger = LoggerFactory.getLogger(ExaminationServicesImpl.class);
ArrayList<Student> studentList = new ArrayList<Student>();
		
		try {
			
			DBConnection connect = new DBConnection();
			connection = connect.getConnection();
			
			statement = connection.createStatement();
			
			String grade, subject;
			grade = student.getGrade();
			subject = student.getSubject();
			
			ResultSet resultset1 = statement.executeQuery("SELECT * FROM STUDENT WHERE CID = '"+ grade +"'");
			
			while (resultset1.next()) {
				Student nStudent = new Student();
				
				nStudent.setIndexNo(resultset1.getInt(1));
				nStudent.setName(resultset1.getString(2));
				nStudent.setGrade(resultset1.getString(7));
				nStudent.setTerm1("");
				nStudent.setTerm2("");
				nStudent.setTerm3("");
				nStudent.setSubject(subject);
				//nStudent.setGrade(resultset1.getString(2));
				studentList.add(nStudent);
				logger.info("0000000000000000000000" + resultset1.getInt(1));
				
				
			}
			
		
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return studentList;
		
		
	}


	@Override
	public void deleteStudentResults(Student student) {
		
		try {
			
			DBConnection connect = new DBConnection();
			connection = connect.getConnection();
			
			statement = connection.createStatement();
			
			String grade = student.getGrade();
			String subject = student.getSubject();
			
			PreparedStatement st = connection.prepareStatement("DELETE FROM student_subject WHERE cid = ? and sid = ?");
			st.setString(1,grade);
			st.setString(2, subject);
			st.executeUpdate(); 
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
