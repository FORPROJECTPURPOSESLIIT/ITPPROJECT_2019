package com.schoolManagment.DAO;

import java.util.List;

import com.schoolManagment.Model.Student;

public interface StudentDAO {

	public List<Student> listAllStudents();
	
	public void AddStudent(Student student);
	
	public void UpdateStudent(Student student);
	
	public void DeleteStudent(int indexNo);
	
	public Student findStudentById(int indexNo);
	
	
	
}
