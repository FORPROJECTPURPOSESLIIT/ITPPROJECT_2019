package com.schoolManagment.Controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.RequestAttributes;

import com.schoolManagment.Model.Home;
import com.schoolManagment.Model.Result;


@Controller
@RequestMapping("/Examination")
public class Examination {
	
	

	@RequestMapping("/selectGrade")
		public String selectGrade() {
			return "gradeSelect#ISHAN#";
	
	}
	
	@RequestMapping("/viewMarks")
	public String viewMarks() {
		return "viewMarks#ISHAN#";

	}
	
	@RequestMapping("/ExaminationServlet")
	public String ExaminationServlet() {
		return "forward:/ExaminationServlet";

	}
	
	@RequestMapping("/ExaminationServiceImpl")
	public String ExaminationServiceImpl() {
		return "ExaminationServiceImpl";

	}
	
	@RequestMapping("/editMarks")
	public String editMarks() {
		return "editMarks#ISHAN#";

	}
	
	@RequestMapping("/EditResultServlet")
	public String editResultServlet() {
		return "forward:/editResultServlet";

	}
	
	@RequestMapping("/updateMarks")
	public String updateMarks() {
		return "updateMarks";

	}
	
	@RequestMapping("/deleteMarks")
	public String deleteMarks() {
		return "deleteMarks";

	}
	
	@RequestMapping("/insertMarks")
	public String insertMarks() {
		return "insertMarks";

	}
	
	@RequestMapping("/selectGradeforinsert")
	public String selectGradeforinsert() {
		return "selectGradeforinsert";

	}
	
	@RequestMapping("/selectGradefordelete")
	public String selectGradefordelete() {
		return "selectGradefordelete";

	}
	
	@RequestMapping("/selectGradeeditorupdate")
	public String selectGradeeditorupdate() {
		return "selectGradeeditorupdate";

	}
	
	@RequestMapping("/insertTimeTable")
	public String insertTimeTable() {
		return "insertTimeTable";

	}
	
	@RequestMapping("/InsertTimeTable")
	public String InsertTimeTable() {
		return "forward:/InsertTimeTable";

	}
	
	@RequestMapping("/DownloadTimeTable")
	public String DownloadTimeTable() {
		return "forward:/DownloadTimeTable";

	}
	
	@RequestMapping("/Message")
	public String Message() {
		return "Message";

	}
	
	@RequestMapping("/IndividualResultsServlet")
	public String IndividualResultsServlet() {
		return "forward:/IndividualResultsServlet";
	}
	
	@RequestMapping("/viewIndiResultsIndex")
	public String viewIndiResultsIndex() {
		return "viewIndiResultsIndex";

	}
	
	@RequestMapping("/viewIndiResults")
	public String viewIndiResults() {
		return "viewIndiResults";

	}
	
	

}
