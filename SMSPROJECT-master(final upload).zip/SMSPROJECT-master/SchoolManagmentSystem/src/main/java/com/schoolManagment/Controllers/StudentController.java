package com.schoolManagment.Controllers;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.schoolManagment.View.ExcelStudentListReportView;
import com.schoolManagment.View.PdfStudentListReportView;
import com.schoolManagment.Model.Student;
import com.schoolManagment.Services.StudentService;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
@RequestMapping("/Student")
public class StudentController {

	@Autowired
	StudentService studentService;
	
	@RequestMapping(value="/list", method = RequestMethod.GET)
	public ModelAndView List() {
		
		Student student = new Student();
		
		ModelAndView model = new ModelAndView("/student/student_page");
		
		List<Student> list = studentService.ListAllStudents();
		model.addObject("studentList", list);
		model.addObject("formData", student);
		
		return model;
		
	}
	
	@RequestMapping(value = "/add" , method = RequestMethod.GET)
	public ModelAndView add() {
		
		ModelAndView model = new ModelAndView("student/student_form");
		
		Student student = new Student();
		model.addObject("AddStudent", student);
		System.out.println("im from add in StudentController");
		return model;
	}
	
	@RequestMapping(value = "/update/{indexNo}", method = RequestMethod.GET )
	public ModelAndView Update(@PathVariable("indexNo") int indexNo) {
		
		ModelAndView model = new ModelAndView("/student/updateStudent");
		
		Student student = studentService.FindStudentById(indexNo);
		model.addObject("AddStudent", student);
		
		return model;
	}
	
	@RequestMapping(value=("/test") , method= RequestMethod.POST)
	public ModelAndView test(@ModelAttribute("AddStudent") Student student) {
		
		studentService.UpdateStudent(student);
		
		return new ModelAndView("redirect:/Student/list");
		
	}
	
	@RequestMapping(value ="/updateStd" , method = RequestMethod.POST)
	public ModelAndView UpdateStudent(@ModelAttribute("AddStudent")Student student) {
		System.out.println("in update");
		studentService.UpdateStudent(student);
		
		return new ModelAndView("redirect:/Student/list");
	}
	
	@RequestMapping(value =("/save") , method= RequestMethod.POST)
	public ModelAndView save(@ModelAttribute("AddStudent") Student student, BindingResult result) {
		System.out.println("im from save"+student);
		studentService.AddStudent(student);
		return new ModelAndView("redirect:/Student/list");
	}
		

	@RequestMapping(value="/delete/{indexNo}", method= RequestMethod.GET )
	public ModelAndView Delete(@PathVariable("indexNo")int indexNo) {
		
		studentService.DeleteStudent(indexNo);
		
		return new ModelAndView("redirect:/Student/list");
		
	}
	@RequestMapping(value = "/student_category" , method = RequestMethod.GET)
	public ModelAndView student_category() {
		
		ModelAndView model = new ModelAndView("student/StudentCategories");
		
		
		return model;
	}
	@RequestMapping(value = "/saveCategory" , method = RequestMethod.GET)
	public ModelAndView saveCategory() {
		
		return new ModelAndView("redirect:/Student/list");
		
		
	
	}
	@RequestMapping(value="/report",method = RequestMethod.GET)
	public ModelAndView studentreport(HttpServletRequest request,HttpServletResponse response) {
		String typereport = request.getParameter("type");
		List<Student> list = studentService.ListAllStudents();
		if(typereport != null && typereport.equals("xls")) {
			return new ModelAndView(new ExcelStudentListReportView(),"StudentList",list);
			
		}else if(typereport != null && typereport.equals("pdf")) {
			return new ModelAndView(new PdfStudentListReportView(), "StudentList",list);
		}
		return new ModelAndView("studentListReport","StudentList",list);
	}
	@RequestMapping(value = "/student_history" , method = RequestMethod.GET)
	public ModelAndView student_history() {
		
		ModelAndView model = new ModelAndView("student/Studenthistory");
		
		
		return model;
	}
	@RequestMapping(value = "/student_report" , method = RequestMethod.GET)
	public ModelAndView student_report() {
		
		ModelAndView model = new ModelAndView("student/StudentListReport");
		
		
		return model;
	}
	
	
}
