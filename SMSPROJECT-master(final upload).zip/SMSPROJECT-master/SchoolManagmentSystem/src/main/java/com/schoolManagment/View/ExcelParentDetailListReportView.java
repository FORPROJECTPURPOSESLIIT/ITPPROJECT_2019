package com.schoolManagment.View;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.schoolManagment.Model.ParentDetails;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsView;

public class ExcelParentDetailListReportView extends AbstractXlsView{

	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		response.setHeader("Content-Disposition", "attachment; filename=\"parentDetails_list.xls\"");
		
		@SuppressWarnings("unchecked")
		List<ParentDetails> list = (List<ParentDetails>) model.get("parentDetails_list");
		
		Sheet sheet = workbook.createSheet("Parent Details List");
		
		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("PARENT ID");	
		header.createCell(1).setCellValue("STUDENT ID");	
		header.createCell(2).setCellValue("PARENT NAME");	
		header.createCell(3).setCellValue("DATE OF BIRTH");	
		header.createCell(4).setCellValue("OCCUPATION");
		header.createCell(5).setCellValue("PHONE NUMBER");	
		
		int rowNum = 1;
		
		for(ParentDetails parentDetails : list ) {
			
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(parentDetails.getParentId());	
			row.createCell(1).setCellValue(parentDetails.getIndexNo());	
			row.createCell(2).setCellValue(parentDetails.getpName());	
			row.createCell(3).setCellValue(parentDetails.getBday());	
			row.createCell(4).setCellValue(parentDetails.getOccupation());
			row.createCell(5).setCellValue(parentDetails.getConatctNo());	
			
			
		}
		
		
	}

	

}
