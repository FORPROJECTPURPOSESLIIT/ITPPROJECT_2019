package com.schoolManagment.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.schoolManagment.Model.Library;

@Repository
public class LibraryDoaImpl implements LibraryDao {

	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate)
			throws DataAccessException {

		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;

	}

	public List<Library> bookList() {
		String sql = "SELECT isbn, bname, author, issuedDate, dateDue FROM books";

		List<Library> list = namedParameterJdbcTemplate.query(sql, getSqlParameterByMOdel(null), new LibraryMapper());

		return list;
	}

	private SqlParameterSource getSqlParameterByMOdel(Library library) {

		MapSqlParameterSource paramSource = new MapSqlParameterSource();

		if (library != null) {
			paramSource.addValue("isbn", library.getIsbn());
			paramSource.addValue("bname", library.getBname());
			//paramSource.addValue("NoOfCopy", library.getNoOfCopy());
			paramSource.addValue("author", library.getAuthor());
			paramSource.addValue("issuedDate", library.getIssuedDate());
			paramSource.addValue("dateDue", library.getDateDue());

		}

		return paramSource;
	}

	private static final class LibraryMapper implements RowMapper<Library> {

		public Library mapRow(ResultSet rs, int rowNum) throws SQLException {

			Library library = new Library();

			library.setIsbn(rs.getString("isbn"));
			library.setBname(rs.getString("bname"));
			//library.setNoOfCopy(rs.getInt("NoOfCopy"));
			library.setAuthor(rs.getString("author"));
			library.setIssuedDate(rs.getString("issuedDate"));
			library.setDateDue(rs.getString("dateDue"));

			return library;
		}
	}

	public void addBookLibrary(Library library) {

		String sql = "INSERT INTO books (`isbn`, `bname`,  `author`, `issuedDate`, `dateDue`) VALUES (:isbn, :bname, :author, :issuedDate, :dateDue);";

		namedParameterJdbcTemplate.update(sql, getSqlParameterByMOdel(library));

	}

	public void updateBookLibrary(Library library) {

		String sql = "UPDATE books SET isbn = :isbn, bname = :bname,  author = :author, issuedDate = :issuedDate, dateDue = :dateDue WHERE isbn = :isbn";

		namedParameterJdbcTemplate.update(sql, getSqlParameterByMOdel(library));
	}

	public void deleteBookLibrary(String isbn) {

		String sql = "DELETE FROM books WHERE isbn = :isbn";

		namedParameterJdbcTemplate.update(sql, getSqlParameterByMOdel(new Library(isbn)));

	}

	public Library findBookByID(String isbn) {

		String sql = "SELECT * FROM	books WHERE isbn = :isbn";

		return namedParameterJdbcTemplate.queryForObject(sql, getSqlParameterByMOdel(new Library(isbn)),
				new LibraryMapper());
	}

	public List<Library> issueBookList() {
		String sql = "SELECT isbn, bname, author, issuedDate, dateDue FROM books";

		List<Library> issuelist = namedParameterJdbcTemplate.query(sql, getSqlParameterByMOdel(null),new LibraryMapper());

		return issuelist;
	}

	public void issueBookLibrary(Library library) {
		System.out.println("in issue book library function"+library);
		//String sql = "UPDATE books SET  issuedDate = :issuedDate, dateDue = :dateDue WHERE isbn = :isbn";
		//String sql = "INSERT INTO books (`bname`,  `author`, `issuedDate`, `dateDue`) VALUES (:bname, :author, :issuedDate, :dateDue) WHERE isbn = :isbn ;";
		String sql = "UPDATE books SET isbn = :isbn, bname = :bname,  author = :author, issuedDate = :issuedDate, dateDue = :dateDue WHERE isbn = :isbn";
		namedParameterJdbcTemplate.update(sql, getSqlParameterByMOdel(library));
	}

	
	public List<Library> viewBookListUsers() {
		String sql = "SELECT isbn, bname, author, issuedDate, dateDue FROM books";

		List<Library> viewlist = namedParameterJdbcTemplate.query(sql, getSqlParameterByMOdel(null),new LibraryMapper());

		return viewlist;
	}
	
	
	}



