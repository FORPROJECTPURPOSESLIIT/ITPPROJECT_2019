package com.schoolManagment.View;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Document;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.PdfWriter;

import com.schoolManagment.Model.Transport;

public class PdfTransportDetailsReportView extends AbstractPdfView{

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		
response.setHeader("Content-Disposition", "attachment; filename=\"transportDetails_list.pdf\"");
		
		
		@SuppressWarnings("unchecked")
		List<Transport> list = (List<Transport>) model.get("transportDetails_list");
		
		Table table = new Table(7);
		table.addCell("DRIVER ID");
		table.addCell("DRIVER NAME");
		table.addCell("VEHICLE ID");
		table.addCell("DESCRIPTION");
		table.addCell("DISTANCE");
		table.addCell("DATE");
		table.addCell("FEE");
		
		for(Transport transport : list ) {
			
			table.addCell(String.valueOf(transport.getDid()));
			table.addCell(transport.getDname());
			table.addCell(transport.getVehicleID());
			table.addCell(transport.getDescription());
			table.addCell(transport.getDistance());
			table.addCell(transport.getTdate());
			table.addCell(transport.getFee());
			
			
			
			
			
		}
		
		
		 document.add(table);
		
	}
		
		
		
	}

	
	
	
	
	
	
	

