package com.schoolManagment.Controllers;

import java.text.DateFormat;
import java.util.Date;

import java.util.Locale;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.schoolManagment.Model.Result;

@Controller
@RequestMapping("/admin")
public class Administration {

	@RequestMapping("/display")
	public String displayAdminPanel(Locale locale, Model model) {
		
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		
		return "adminPanel";
	}
	
	@RequestMapping("/addTeachers")
	public String AddTeachers() {
	
		return "addTeachers";
	}
	
	
	
	@RequestMapping("/result")
	public String result(@ModelAttribute Result result) {
		System.out.println(result);
		System.out.println("result function invoke");
		return "adminPanel";
	}
	
	@RequestMapping("/sample")
	public String showTransport() {
		return "login";
	}
	
}
