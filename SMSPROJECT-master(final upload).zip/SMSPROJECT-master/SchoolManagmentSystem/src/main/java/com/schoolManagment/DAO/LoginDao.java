//package com.schoolManagment.DAO;
//
//import java.util.List;
//
//import com.schoolManagment.Model.UserData;
//
//public interface LoginDao {
//
//	UserData findUserInfo(String username);
//	
//	List<String> getUserRoles(String username);
//	
//	
//}
