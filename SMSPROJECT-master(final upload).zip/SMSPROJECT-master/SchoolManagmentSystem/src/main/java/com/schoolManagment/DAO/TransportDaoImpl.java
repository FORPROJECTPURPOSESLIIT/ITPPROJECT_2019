package com.schoolManagment.DAO;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.schoolManagment.Model.Transport;


@Repository
public class TransportDaoImpl implements TransportDao {
	
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Autowired
	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) throws DataAccessException{
	
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
		
		
	} 

	
	public List<Transport> listAllTransport() {
		
		String sql = "SELECT did, dname, vehicleID, description, distance, tdate, fee FROM transport";
		
		List<Transport> list =  namedParameterJdbcTemplate.query(sql, getSqlParameterByModel(null), new TransportMapper());
		
		return list;
	}
	
	private SqlParameterSource getSqlParameterByModel(Transport transport) {
		
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		if(transport != null ) {
			
			paramSource.addValue("did", transport.getDid());
			paramSource.addValue("dname", transport.getDname());
			paramSource.addValue("vehicleID", transport.getVehicleID());
			paramSource.addValue("description", transport.getDescription());
			paramSource.addValue("distance", transport.getDistance());
			paramSource.addValue("tdate", transport.getTdate());
			paramSource.addValue("fee", transport.getFee());
		}
		return paramSource;
	}
	
	private static final class TransportMapper implements RowMapper<Transport>{
		
		public Transport mapRow(ResultSet rs, int rowNum) throws SQLException{
			
			Transport transport = new Transport();
			transport.setDid(rs.getString("did"));
			transport.setDname(rs.getString("dname"));
			transport.setVehicleID(rs.getString("vehicleID"));
			transport.setDescription(rs.getString("description"));
			transport.setDistance(rs.getString("distance"));
			transport.setTdate(rs.getString("tdate"));
			transport.setFee(rs.getString("fee"));
			
			return transport;
		}
	}
	

	@Override
	public void addTransport(Transport transport) {
		
		String sql = "INSERT INTO transport(did, vehicleID, dname, description, distance, tdate, fee) VALUES (:did, :vehicleID, :dname, :description, :distance, :tdate, :fee)";
		
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(transport));
		
	}

	@Override
	public void updateTransport(Transport transport) {
		
		
		String sql = "UPDATE transport SET dname = :dname , vehicleID = :vehicleID , description = :description , distance = :distance , tdate = :tdate, fee = :fee WHERE did = :did";
	
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(transport));
	
	}

	@Override
	public void deleteTransport(String did) {
		
		
		String sql = "DELETE FROM transport WHERE did = :did";
		
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(new Transport(did)));
	}

	@Override
	public Transport findTransportById(String did) {
		
		String sql = "SELECT * FROM transport WHERE did = :did";
		
		
		return namedParameterJdbcTemplate.queryForObject(sql, getSqlParameterByModel(new Transport(did)), new TransportMapper());
	}

	
	
	
	
	
	
	
	
}

