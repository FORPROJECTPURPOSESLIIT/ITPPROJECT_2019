package com.schoolManagment.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.schoolManagment.Model.EmpSal;
import com.schoolManagment.Services.EmpSalService;

@Controller
@RequestMapping(value="/empsal")
public class EmpSalController {
	
	@Autowired
	EmpSalService empsalservice;

	
	@RequestMapping(value="/list1", method=RequestMethod.GET)
	public ModelAndView list1() {
		
		ModelAndView model = new ModelAndView("Employee/empsal_page");
		
		List<EmpSal> list = empsalservice.listAllEmpSal();
		model.addObject("listEmpSal",list);
		return model;
		
		
	}
	
	@RequestMapping(value="/addEmp", method=RequestMethod.GET)
	public ModelAndView addEmp() {
		
		ModelAndView model = new ModelAndView("Employee/empsal_form");
		
		
		EmpSal empsal = new EmpSal();
		model.addObject("empForm",empsal);
		return model;
		
		
	}
	
	@RequestMapping(value="/updateEmp/{empId}", method=RequestMethod.GET)
	public ModelAndView updateEmp(@PathVariable("empId")String empId) {
		
		ModelAndView model = new ModelAndView("Employee/empsal_form");
		
		
		EmpSal empsal = empsalservice.findEmpSalById(empId);
		model.addObject("empForm",empsal);
		return model;
		
}

	@RequestMapping(value="/saveEmpSal/{empId}", method=RequestMethod.POST)
	public ModelAndView saveEmpSal(@ModelAttribute("empsalform")EmpSal empsal) {
		
		if(empsal != null && empsal.getEmpId() != null) {
			
			empsalservice.updateEmpSal(empsal);
			
		}else{
			empsalservice.addEmpSal(empsal);
		}
		return new ModelAndView("redirect:/list");
}
	
	@RequestMapping(value="/deleteEmpSal/{empId}", method=RequestMethod.GET)
	public ModelAndView deleteEmpSal(@PathVariable("empId")String empId) {
		
		
		
		empsalservice.deleteEmpSal(empId);
		

		return new ModelAndView("redirect:/list");
}
}