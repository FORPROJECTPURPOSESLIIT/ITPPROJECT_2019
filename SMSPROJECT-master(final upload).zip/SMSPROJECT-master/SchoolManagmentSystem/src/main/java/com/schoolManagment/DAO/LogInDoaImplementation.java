//package com.schoolManagment.DAO;
//
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.jdbc.core.RowMapper;
//import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
//import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
//import org.springframework.jdbc.core.namedparam.SqlParameterSource;
//import org.springframework.stereotype.Repository;
//import org.springframework.web.servlet.tags.ParamAware;
//
//import com.schoolManagment.Model.UserData;
//
//@Repository
//public class LogInDoaImplementation implements LoginDao{
//
//	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
//	
//	@Autowired
//	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
//		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
//	}
//	
//
//	@Override
//	public UserData findUserInfo(String username) {
//		
//		String sql = "SELECT name,password from users WHERE name = :username";
//		
//		UserData userData = namedParameterJdbcTemplate.queryForObject(sql, getSqlParameterSource(username,""), new UserInfoMapper() );
//		
//		return userData;
//	}
//	
//	private static final class UserInfoMapper implements RowMapper<UserData>{
//
//		@Override
//		public UserData mapRow(ResultSet rs, int rowNum) throws SQLException {
//			
//		 String username = rs.getString("name");
//		 String password = rs.getString("password");
//			
//			
//			return new UserData(username, password);
//		}
//		
//		
//		
//	}
//	
//	
//	 private SqlParameterSource getSqlParameterSource(String username, String password) {
//		 
//		 MapSqlParameterSource parameterSource = new MapSqlParameterSource();
//		 parameterSource.addValue("name", username);
//		 parameterSource.addValue("password", password);
//		 
//		 
//		 return parameterSource;
//		 
//	 }
//	
//	
//
//	@Override
//	public List<String> getUserRoles(String username) {
//		
//		String sql = "SELECT user_role FROM role WHERE user_role = :username";
//		
//		List<String> roles = namedParameterJdbcTemplate.queryForList(sql, getSqlParameterSource(username, ""),String.class);
//		
//		return roles; 
//	}
//
//}
