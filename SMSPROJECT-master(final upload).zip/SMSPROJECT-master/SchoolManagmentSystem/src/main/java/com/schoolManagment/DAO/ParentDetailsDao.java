package com.schoolManagment.DAO;

import java.util.List;

import com.schoolManagment.Model.ParentDetails;


public interface ParentDetailsDao {

    public List<ParentDetails> listAllParentDetails();
	
	public void addParentDetails(ParentDetails parentDetails);
	
	public void updateParentDetails(ParentDetails parentDetails);
	
	public void deleteParentDetails(String parentId);
	
	public ParentDetails findParentDetailsById(String parentId);
	
	public List<ParentDetails> findParentDetails(String parentId, String txt);
	
	
	
	
	
	
	
}
