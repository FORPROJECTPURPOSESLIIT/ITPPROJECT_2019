
package com.schoolManagment.Controllers;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.schoolManagment.Model.Event;
import com.schoolManagment.Model.Finance;
import com.schoolManagment.Services.EventService;

@Controller
@RequestMapping(value="/event")
public class EventControl {
	
	@Autowired
	EventService eventService;
	
	@RequestMapping(value="/list", method= RequestMethod.GET)
	public ModelAndView list() {
		
		ModelAndView model = new ModelAndView("/event/EventInformation");
		List<Event> list = eventService.listAllEvents();
		model.addObject("listEvents",list);
		
		return model;
		
		
	}
	
	@RequestMapping(value="/add", method= RequestMethod.GET)
	public ModelAndView add() {
		
		ModelAndView model = new ModelAndView("/event/AddNewEvent");
		System.out.println("in add function");
		Event event = new Event();
		model.addObject("AddEvent",event);
		return model;
	
}
	


	@RequestMapping(value="/update/{eventId}", method= RequestMethod.GET)
	public ModelAndView update(@PathVariable("eventId") String eventId) {
		
		ModelAndView model = new ModelAndView("/event/updateEvent");
		
		Event event = eventService.findEventById(eventId);
		model.addObject("eventForm",event);
		return model;
	
}

	@RequestMapping(value="/save", method= RequestMethod.POST)
	public ModelAndView save(@ModelAttribute("eventForm") Event event) {
		System.out.println("in save");
		
		if(event != null && event.getEventId() != null ) {
			//update
			System.out.println("in save");
			eventService.updateEvent(event);
			
		}
		else {
			//add new
			System.out.println("in save");
			eventService.addEvent(event);
			}
		
			return new ModelAndView("redirect:/event/list");
		
	}
	
	
	@RequestMapping(value="/fetch", method= RequestMethod.POST)
	public ModelAndView fetch(@ModelAttribute("AddEvent") Event event) {
		System.out.println("in save"+event);
		
			eventService.addEvent(event);
		
			return new ModelAndView("redirect:/event/list");
		
	}

	@RequestMapping(value="/delete/{eventId}", method= RequestMethod.GET)
	public ModelAndView delete(@PathVariable("eventId") String eventId) {
		
		eventService.deleteEvent(eventId);
		return new ModelAndView("redirect:/event/list");
	
	 
}
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView SearchEvents(@ModelAttribute("listEvents")Event event) {
		
		String eventId = event.getEventId();
		
		Event searchlist = eventService.findEventById(eventId);
		ModelAndView model = new ModelAndView("/event/Search");
		model.addObject("searchResult", searchlist);
		
		return model;
	}
	
	
} 

