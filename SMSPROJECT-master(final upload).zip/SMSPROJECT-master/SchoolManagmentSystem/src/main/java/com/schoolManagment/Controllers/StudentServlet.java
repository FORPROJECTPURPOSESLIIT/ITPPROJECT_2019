//package com.schoolManagment.Controllers;
//
//import java.io.IOException;
//import java.util.ArrayList;
//
//import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletException;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import com.schoolManagment.Model.Student;
//import com.schoolManagment.Services.ExaminationServiceInterface;
//import com.schoolManagment.Services.ExaminationServicesImpl;
//import com.schoolManagment.Services.studentServiceImplementation;
//import com.schoolManagment.Services.studentServiceInterface;
//
///**
// * Servlet implementation class StudentServlet
// */
//public class StudentServlet extends HttpServlet {
//	private static final long serialVersionUID = 1L;
//       
//    /**
//     * @see HttpServlet#HttpServlet()
//     */
//    public StudentServlet() {
//        super();
//        // TODO Auto-generated constructor stub
//    }
//
//	/**
//	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
//	 */
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
//	}
//
//	/**
//	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
//	 */
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		
//		
//		final Logger logger = LoggerFactory.getLogger(ExaminationServlet.class);
//		logger.info("Welcome **********************************************************************************************.");
//		
//		Student student = new Student();
//		ArrayList<Student> studentList;
//		
//		String grade = request.getParameter("hiddenValue");
//	
//		student.setGrade(grade);
//		
//		logger.info("====================" + student.getGrade());
//		
//		studentServiceInterface studentDetails = new studentServiceImplementation();
//		
//		studentList = studentDetails.getStudentDetails(student);
//		
//
//		
//		
//		request.setAttribute("grade", grade);
//		request.setAttribute("studentList", studentList);
//		
//		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Student/viewStudentDetails");
//		dispatcher.forward(request, response);
//	}
//
//}
