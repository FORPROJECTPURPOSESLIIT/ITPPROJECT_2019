package com.schoolManagment.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.schoolManagment.Model.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDAO{
	
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	
	@Autowired
	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) throws DataAccessException{
	
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
		
	}

	public List<Employee> listAllEmployees() {
		
		String sql = "Select empId,name,address,dob,joinDate,gender,phoneNo,idetails from employee";
		
		List<Employee> list = namedParameterJdbcTemplate.query(sql, getSqlParameterByModel(null), new EmployeeMapper());

		return list;
	}
	private SqlParameterSource getSqlParameterByModel(Employee employee) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		if(employee != null) {
				paramSource.addValue("empId",employee.getEmpId() );
				paramSource.addValue("name",employee.getName() );
				paramSource.addValue("address",employee.getAddress() );
				paramSource.addValue("dob", employee.getDob());
				paramSource.addValue("joinDate",employee.getJoinDate() );
				paramSource.addValue("gender", employee.getGender());
				paramSource.addValue("phoneNo", employee.getPhoneNo());
				paramSource.addValue("idetails", employee.getIdetails());

		
	
		}
		
		return paramSource;
		
	}
	private static final class EmployeeMapper implements RowMapper<Employee>{
		
		public Employee mapRow(ResultSet rs, int rowNum) throws SQLException{
			
			Employee employee = new Employee();
			
			employee.setEmpId(rs.getString("empId"));
			employee.setName(rs.getString("name"));
			employee.setAddress(rs.getString("address"));
			employee.setDob(rs.getString("dob"));
			employee.setJoinDate(rs.getString("joinDate"));
			employee.setGender(rs.getInt("gender"));
			employee.setPhoneNo(rs.getInt("phoneNo"));
			employee.setIdetails(rs.getString("idetails"));
			
			return employee;
		}
	}


	public void addEmployees(Employee employee) {
		String sql = "INSERT INTO `employee` (`empId`, `name`, `address`, `dob`, `joinDate`, `gender`, `phoneNo`, `idetails`) VALUES (:empId,:name ,:address ,:dob ,:joinDate ,:gender,:phoneNo ,:idetails );";
		System.out.println(sql);
		
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(employee));
		
	
	}


	public void updateEmployees(Employee employee) {
		String sql = "UPDATE employee SET name=:name,address=:address,dob=:dob,joinDate=:joinDate,gender=:gender,phoneNo=:phoneNo,idetails=:idetails Where empId =:empId";
		System.out.println(sql);
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(employee));

	
	}


	public void deleteUser(String empId) {
		
		String sql = "DELETE FROM employee WHERE empId = :empId";
		
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(new Employee(empId)));

		
		
	}


	public Employee findEmployeeById(String empId) {
		
		String sql = "SELECT * from employee WHERE empId=:empId";
		return namedParameterJdbcTemplate.queryForObject(sql, getSqlParameterByModel(new Employee(empId)), new EmployeeMapper());
	}

}
