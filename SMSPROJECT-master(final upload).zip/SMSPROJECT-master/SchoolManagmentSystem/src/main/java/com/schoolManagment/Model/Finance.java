package com.schoolManagment.Model;

public class Finance {

	
	 private String recordId;
	private String sponserDetails;
	private double expenditure;
	private double income ;
	private String description ;
	
	public Finance() {
		super();
	}

	public Finance(String recordId) {
		super();
		this.recordId = recordId;
	}

	public String getRecordId() {
		return recordId;
	}

	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	public String getSponserDetails() {
		return sponserDetails;
	}

	public void setSponserDetails(String sponserDetails) {
		this.sponserDetails = sponserDetails;
	}

	public double getExpenditure() {
		return expenditure;
	}

	public void setExpenditure(double expenditure) {
		this.expenditure = expenditure;
	}

	public double getIncome() {
		return income;
	}

	public void setIncome(double income) {
		this.income = income;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Finance [recordId=" + recordId + ", sponserDetails=" + sponserDetails + ", expenditure=" + expenditure
				+ ", income=" + income + ", description=" + description + "]";
	}  
	
	
	
	
}
