package com.schoolManagment.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.schoolManagment.DAO.ClassDao;
import com.schoolManagment.Model.ClassData;

@Service
public class ClassServiceImpl implements ClassService{

	ClassDao classDao;
	
	@Autowired
	public void setClassDao(ClassDao classDao) {
		this.classDao = classDao;
	}


	public List<ClassData> listAllClasses() {
		
		return classDao.listAllClasses();
	}

	
	public void addClass(ClassData data) {

			classDao.addClass(data);
		
	}

	
	public void updateClass(ClassData data) {
		
		
		classDao.updateClass(data);
		
	}

	
	public void deleteClass(String cid) {
		
		classDao.deleteClass(cid);
		
	}

	
	public ClassData findClassByID(String cid) {
		
		return classDao.findClassByID(cid);
	}


	@Override
	public ClassData SearchClass(String cid) {
		
		return classDao.SearchClass(cid);
	}

}
