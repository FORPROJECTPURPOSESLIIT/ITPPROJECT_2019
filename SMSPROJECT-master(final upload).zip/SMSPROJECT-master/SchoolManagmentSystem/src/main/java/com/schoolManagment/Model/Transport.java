package com.schoolManagment.Model;

public class Transport {
	
	    private String did;
	    private String dname;
	    private String vehicleID;
	    private String description;
	    private String distance;
	    private String tdate;
	    private String fee;
	    
	    
	   public Transport() {
			super();
		}
	   
		public Transport(String did) {
			super();
			this.did = did;
		}
		
		public String getDid() {
			return did;
		}
		public void setDid(String did) {
			this.did = did;
		}
		public String getDname() {
			return dname;
		}
		public void setDname(String dname) {
			this.dname = dname;
		}
		public String getVehicleID() {
			return vehicleID;
		}
		public void setVehicleID(String vehicleID) {
			this.vehicleID = vehicleID;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getDistance() {
			return distance;
		}
		public void setDistance(String distance) {
			this.distance = distance;
		}
		public String getFee() {
			return fee;
		}
		public void setFee(String fee) {
			this.fee = fee;
		}
		

		public String getTdate() {
			return tdate;
		}

		public void setTdate(String tdate) {
			this.tdate = tdate;
			
		}

		@Override
		public String toString() {
			return "Transport [did=" + did + ", dname=" + dname + ", vehicleID=" + vehicleID + ", description="
					+ description + ", distance=" + distance + ", tdate=" + tdate + ", fee=" + fee + "]";
		}

		

		
	    
		
		
		
}
