package com.schoolManagment.Model;

import java.sql.Timestamp;

public class Employee {

	private String empId;
	private String name;
	private String address;
	private  String dob;
	private String joinDate;
	private int gender;
	private int phoneNo;
	private String idetails;

	public Employee() {
		super();
	}

	public Employee(String empId) {
		super();
		this.empId = empId;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(String joinDate) {
		this.joinDate = joinDate;
	}

	public int getGender() {
		return gender;
	}

	public void setGender(int gender) {
		this.gender = gender;
	}

	public int getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getIdetails() {
		return idetails;
	}

	public void setIdetails(String idetails) {
		this.idetails = idetails;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", address=" + address + ", dob=" + dob + ", joinDate="
				+ joinDate + ", gender=" + gender + ", phoneNo=" + phoneNo + ", idetails=" + idetails + "]";
	}

}
