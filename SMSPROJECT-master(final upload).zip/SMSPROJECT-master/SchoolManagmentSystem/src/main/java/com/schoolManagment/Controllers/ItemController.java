package com.schoolManagment.Controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.schoolManagment.Model.Item;
import com.schoolManagment.Services.ItemService;
import com.schoolManagment.View.ExcelItemListReportView;
import com.schoolManagment.View.PdfItemListReportView;

@Controller
@RequestMapping(value = "/item")
public class ItemController {

	@Autowired
	ItemService itemService;

	// ----------------------------View Database Entries-------------------------------
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		Item item = new Item();

		ModelAndView model = new ModelAndView("/item/item_page");

		List<Item> list = itemService.ListAllItems();
		model.addObject("ItemList", list);

		return model;
	}

	// ---------------------------------------calling the add function and redirect to addItems.jsp ...................................
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView add() {

		ModelAndView model = new ModelAndView("/item/item_form");

		Item item = new Item();
		model.addObject("AddForm", item); // creating a binding model attribute

		return model;
	}

	// ...........................................view the updating the records page ...........................................

	@RequestMapping(value = "/update/{toolNo}", method = RequestMethod.GET)
	public ModelAndView update(@PathVariable("toolNo") String toolNo) {

		ModelAndView model = new ModelAndView("/item/update");

		Item item = itemService.findItemById(toolNo);
		model.addObject("AddForm", item);
		return model;
	}

	// ............................. fetching the data from form to database......................................................

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView save(@Valid @ModelAttribute("AddItem") Item item, BindingResult result) {

		itemService.updateItems(item);
		return new ModelAndView("redirect:/item/list");
	}

	// ...................... fetching updated data................................................................

	@RequestMapping(value = "/fetch", method = RequestMethod.POST)
	public ModelAndView updateItem(@Valid @ModelAttribute("AddItem") Item item, BindingResult result) {

		if (item != null || item.getToolNo() != null) {
			// update
			itemService.addItems(item);

		} else {
			// add new Class
			itemService.updateItems(item);

		}
		System.out.println(item);
		return new ModelAndView("redirect:/item/list");
	}

	// ........................ Delete function .........................................
	@RequestMapping(value = "/delete/{toolNo}", method = RequestMethod.GET)
	public ModelAndView delete(@PathVariable("toolNo") String tool) {

		itemService.deleteItems(tool);
		return new ModelAndView("redirect:/item/list");
	}

	// ----------------------Report Generation--------------------------------------

	@RequestMapping(value = "/report", method = RequestMethod.GET)
	public ModelAndView userListReport(HttpServletRequest req, HttpServletResponse res) {

		String typeReport = req.getParameter("type");

		List<Item> list = new ArrayList<Item>();
		list = itemService.ListAllItems();

		if (typeReport != null && typeReport.equals("xls")) {
			return new ModelAndView(new ExcelItemListReportView(), "itemList", list);
		} else if (typeReport != null && typeReport.equals("pdf")) {
			return new ModelAndView(new PdfItemListReportView(), "itemList", list);
		}

		return new ModelAndView("itemListReport", "itemList", list);
	}
	
	//-----------------------Search---------------------------
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView SearchClass(@ModelAttribute("AddForm")Item item)
	{
		String toolNo = item.getToolNo();
		
		Item item2 = itemService.findItemById(toolNo);
		ModelAndView model = new ModelAndView("/item/search");
		model.addObject("searchResult", item2);
		
		
		return  model;
				
	}
	
	//------------Demo---------------------------
	@RequestMapping(value = "/autoFill", method = RequestMethod.GET)
	public ModelAndView autoFill(Item item)
	{
		ModelAndView model = new ModelAndView("item/item_page");
		
		item.setToolNo("SC010");
		item.setToolName("Volumetric Flasks");
		item.setItemType("Handle With Care");
		item.setQuantity("4");
		item.setInvenType("Science Lab");
		
		itemService.addItems(item);
		model.addObject("item_page",item);
		
		List<Item> list = itemService.ListAllItems();
		model.addObject("ItemList", list);
		return model;
	}
	
}
