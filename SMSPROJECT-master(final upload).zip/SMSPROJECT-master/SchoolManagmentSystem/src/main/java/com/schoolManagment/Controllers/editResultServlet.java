package com.schoolManagment.Controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.schoolManagment.Model.Student;
import com.schoolManagment.Services.ExaminationServicesImpl;

/**
 * Servlet implementation class editResultServlet
 */
public class editResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public editResultServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		final Logger logger = LoggerFactory.getLogger(editResultServlet.class);
		logger.info("2 nd servlet");
		
		
		
		
		if(ExaminationServlet.whereToGo == 2) {
			
			logger.info("else if(ExaminationServlet.whereToGo == 2)");
			
		
	        String j = request.getParameter("hiddenValue");
	        String gragrade = request.getParameter("hiddenValue3");
	        
	        
	        Student student = new Student();
	
	        for(int i = 0 ; i < Integer.parseInt(j) ; i++ ) {
				String k = Integer.toString(i);
				student.setIndexNo(Integer.parseInt(request.getParameter("indexNo" + k)));
				
				student.setTerm1(request.getParameter("t1" + k)); 
				
				student.setTerm2(request.getParameter("t2" + k));
		
				student.setTerm3(request.getParameter("t3" + k));
				
				student.setSubject(request.getParameter("hiddenValue2"));
				
				new ExaminationServicesImpl().updateClassResults(student);
		
			}
	        
	        String subject = student.getSubject();
	        String grade = gragrade;
	        
	        
	        logger.info(subject);
	        logger.info(grade);
	        
	        request.setAttribute("hiddenValue", grade);
			request.setAttribute("hiddenValue1", subject);
			ExaminationServlet.increment = 0;
			
	        
	        RequestDispatcher rd = request.getServletContext().getRequestDispatcher("/Examination/ExaminationServlet");
	        rd.forward(request,response);
	        
	        
	        
		}else if(ExaminationServlet.whereToGo == 4) {
			int term = Integer.parseInt(request.getParameter("hiddenValue4"));
			
			logger.info("else if(ExaminationServlet.whereToGo == 4)");
			logger.info("***************"+ term);
			
			if(term == 1) {
				
			logger.info("in term 111111111111111111111111111111111111111");
		        String j = request.getParameter("hiddenValue");
		        String gragrade = request.getParameter("hiddenValue3");
		        
		        Student student = new Student();
		
		        for(int i = 0 ; i < Integer.parseInt(j) ; i++ ) {
					String k = Integer.toString(i);
					student.setIndexNo(Integer.parseInt(request.getParameter("indexNo" + k)));
					
					student.setTerm1(request.getParameter("t1" + k)); 
					
					student.setGrade(gragrade);
					
					student.setSubject(request.getParameter("hiddenValue2"));
					
					new ExaminationServicesImpl().insertResults(student);
			
				}
		        
		        String subject = student.getSubject();
		        String grade = gragrade;
		        
		        
		        logger.info(subject);
		        logger.info(grade);
		        
		        RequestDispatcher rd = request.getServletContext().getRequestDispatcher("/admin/result");
		        rd.forward(request,response);
		        
		        
			}else if(term == 2) {
				
				logger.info("in term 22222222222222222222222222222");
				
				String j = request.getParameter("hiddenValue");
		        String gragrade = request.getParameter("hiddenValue3");
		        
		        Student student = new Student();
		
		        for(int i = 0 ; i < Integer.parseInt(j) ; i++ ) {
					String k = Integer.toString(i);
					student.setIndexNo(Integer.parseInt(request.getParameter("indexNo" + k)));
					
					student.setTerm2(request.getParameter("t1" + k));
					
					student.setGrade(gragrade);
					
					student.setSubject(request.getParameter("hiddenValue2"));
					
					new ExaminationServicesImpl().update2ndtermResults(student);
			
				}
		        
		        String subject = student.getSubject();
		        String grade = gragrade;
		        
		        
		        logger.info(subject);
		        logger.info(grade);
		        
		        RequestDispatcher rd = request.getServletContext().getRequestDispatcher("/admin/result");
		        rd.forward(request,response);
		        
		        
			}else if(term == 3) {
				
				String j = request.getParameter("hiddenValue");
		        String gragrade = request.getParameter("hiddenValue3");
		        
		        Student student = new Student();
		
		        for(int i = 0 ; i < Integer.parseInt(j) ; i++ ) {
					String k = Integer.toString(i);
					student.setIndexNo(Integer.parseInt(request.getParameter("indexNo" + k)));
					
					student.setTerm3(request.getParameter("t1" + k));
					
					student.setGrade(gragrade);
					
					student.setSubject(request.getParameter("hiddenValue2"));
					
					new ExaminationServicesImpl().update3rdtermResults(student);
			
				}
		        
		        String subject = student.getSubject();
		        String grade = gragrade;
		        
		        
		        logger.info(subject);
		        logger.info(grade);
	
		        
		        RequestDispatcher rd = request.getServletContext().getRequestDispatcher("/admin/result");
		        rd.forward(request,response);
		        
		        
			}
			
			
			
		}else if(ExaminationServlet.whereToGo == 3) {
			
		}
		

	}

}
