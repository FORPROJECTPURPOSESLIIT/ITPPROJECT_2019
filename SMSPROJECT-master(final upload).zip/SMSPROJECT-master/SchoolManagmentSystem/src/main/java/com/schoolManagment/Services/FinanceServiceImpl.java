package com.schoolManagment.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.schoolManagment.DAO.FinanceDao;
import com.schoolManagment.Model.Finance;
@Service
public class FinanceServiceImpl implements FinanceService {

	FinanceDao financeDao;
	
	
	@Autowired
	public void setFinanceDao(FinanceDao financeDao) {
		this.financeDao = financeDao;
	}

	@Override
	public List<Finance> listAllFinance() {
		
		return financeDao.listAllFinance();
	}

	@Override
	public void addFinance(Finance finance) {
		
		financeDao.addFinance(finance);
	}

	@Override
	public void updateFinance(Finance finance) {
		
		financeDao.updateFinance(finance);
	}

	@Override
	public void deleteFinance(String recordId) {
		
		financeDao.deleteFinance(recordId);
		
	}

	@Override
	public Finance findFinanceByID(String recordId) {
		
		return financeDao.findFinanceByID(recordId);
	}

}
