package com.schoolManagment.Model;
import java.util.Date;

public class Student {

	private int indexNo, phone;
	private String term1, term2, term3, subject, grade, name, address, bday, did, isbn, gender, password;
	private String cid;
	
	
	
	public Student(int indexNo) {
		super();
		this.indexNo = indexNo;
	}
	
	public Student() {
		super();
		this.term1 = null;
		this.term2 = null;
		this.term3 = null;
	}
	
	
	
	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public int getIndexNo() {
		return indexNo;
	}
	
	public void setIndexNo(int indexNo) {
		this.indexNo = indexNo;
	}
	
	public String getTerm1() {
		return term1;
	}
	
	public void setTerm1(String term1) {
		this.term1 = term1;
	}
	
	public String getTerm2() {
		return term2;
	}
	
	public void setTerm2(String term2) {
		this.term2 = term2;
	}
	
	public String getTerm3() {
		return term3;
	}
	
	public void setTerm3(String term3) {
		this.term3 = term3;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBday() {
		return bday;
	}

	public void setBday(String bday) {
		this.bday = bday;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	public String getDid() {
		return did;
	}

	public void setDid(String did) {
		this.did = did;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	
	
	
	
	
}
