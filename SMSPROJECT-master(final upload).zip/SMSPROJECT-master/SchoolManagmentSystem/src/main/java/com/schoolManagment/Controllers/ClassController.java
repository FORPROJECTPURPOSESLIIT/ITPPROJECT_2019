package com.schoolManagment.Controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.schoolManagment.Model.ClassData;
import com.schoolManagment.Model.Employee;
import com.schoolManagment.Model.Item;
import com.schoolManagment.Services.ClassService;
import com.schoolManagment.Services.EmployeeService;
import com.schoolManagment.Services.ItemService;
import com.schoolManagment.View.ExcelClassListReportView;
import com.schoolManagment.View.PdfClassListReportView;

@Controller
@RequestMapping(value= "/class")
public class ClassController {

	@Autowired
	ClassService classService;
	@Autowired
	EmployeeService employeeService ;
	@Autowired
	ItemService itemService ; 

//.................................................. view the database records	..............................
	@RequestMapping(value="/list", method = RequestMethod.GET)			
	public ModelAndView list() {
		
		ClassData data = new ClassData();
		
		ModelAndView model = new ModelAndView("/Class/viewClass");
		
		List<ClassData> list = classService.listAllClasses();
		model.addObject("ClassList", list);
		model.addObject("formData", data);
		
		return model;
	}
	
//........................................ calling the add function and redirect to addClass.jsp ...................................
	
	@RequestMapping(value="/add", method = RequestMethod.GET)			
	public ModelAndView add() {
		
		ModelAndView model = new ModelAndView("/Class/newItemAdd");
		
		ClassData data = new ClassData();
		model.addObject("AddClass", data);							//creating a binding model attribute
		
		return model;
	}
	
//...........................................view the  updating the records page .............................................	
	
	@RequestMapping(value="/update/{cid}", method = RequestMethod.GET)
	public ModelAndView update(@PathVariable("cid") String cid) {
		
		List<Employee> list = employeeService.listAllEmployees();
		
		ModelAndView model = new ModelAndView("/Class/addClass");
		
		ClassData data = classService.findClassByID(cid);
		model.addObject("AddClass", data);
		model.addObject("EmployeeList", list);
		return model;
	}
	
//.............................	Update the data from form to database..........................................................
	
	@RequestMapping(value="/save", method = RequestMethod.POST)
	public ModelAndView save(@Valid @ModelAttribute("AddClass") ClassData data , BindingResult result) {
		
		
		if(data != null && data.getCid() != null) {
			//update
			classService.updateClass(data);
			
			
			
		}else {
			//add new Class
			classService.addClass(data);
			
		}
		System.out.println(data);
		return new ModelAndView("redirect:/class/list");
	}
	
//...................... Save  data .....................................................................
	
	@RequestMapping(value="/fetch", method = RequestMethod.POST)
	public ModelAndView updateItem(@Valid @ModelAttribute("AddClass") ClassData data , BindingResult result) {
		
		
		
		if(data != null && data.getCid() != null) {
			//update
			classService.addClass(data);
			
			
			
		}else {
			//add new Class
			
			classService.updateClass(data);
		}
		System.out.println(data);
		return new ModelAndView("redirect:/class/list");
	}
	
//........................ Delete function ..............................................................................	
	
	@RequestMapping(value="/delete/{cid}", method = RequestMethod.GET)
	public ModelAndView delete(@PathVariable("cid") String cid) {
		
		classService.deleteClass(cid);
		
		return new ModelAndView("redirect:/class/list");
	}
	
//............................ report Generating function ...........................................................
	@RequestMapping(value="/report" , method = RequestMethod.GET)
	public ModelAndView classreport(HttpServletRequest request , HttpServletResponse response) {
		
		String typereport = request.getParameter("type");
		
		List<ClassData> list = classService.listAllClasses();
		
		if(typereport != null && typereport.equals("xls")) {
			return new ModelAndView(new ExcelClassListReportView(), "ClassList", list);
		}else if(typereport != null && typereport.equals("pdf")) {
			return new ModelAndView(new PdfClassListReportView(), "ClassList", list);
		}
		
		return new ModelAndView("classListReport", "ClassList", list);
		
	}
	
//..........................  Search function ............................................................................	
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView SearchClass(@ModelAttribute("formData")ClassData data) {
		
		String cid = data.getCid();
		
		ClassData data2 = classService.findClassByID(cid);
		ModelAndView model = new ModelAndView("/Class/Search");
		model.addObject("searchResult", data2);
		
		return model;
		
	}
	
//......................... ViewMore details function .....................................................................
@RequestMapping(value="/more/{cid}", method = RequestMethod.GET)	
public ModelAndView ViewMore(@PathVariable("cid") String cid) {
	
	String empId = null;
	String toolNo = null;
	
	ModelAndView model = new ModelAndView("/Class/ViewMore");
	
	ClassData data = classService.findClassByID(cid);
	
	empId = data.getEmpid();
	toolNo = data.getToolNo();
	
	
	Employee data2  = employeeService.findEmployeeById(empId);

	List<Item> list = itemService.ListAllClassItems(toolNo);

	model.addObject("ClassList", data);
	model.addObject("EmployeeData", data2);
	model.addObject("ItemData", list);
	
	
	return model;
}	
	

//................... Demo Button .......................................................
@RequestMapping(value="/demo" , method = RequestMethod.GET)
public ModelAndView Demo() {
	ModelAndView model = new ModelAndView("/Class/newItemAdd");
	ClassData data = new ClassData();
	
	String cid = "10A";
	String name = "Grade-10A";
	String empid = "t001";
	String toolId = "001";
	
	data.setCid(cid);
	data.setcName(name);
	data.setEmpid(empid);
	data.setToolNo(toolId);
	
	model.addObject("AddClass", data);
	
	return model;
	
} 

//............................ Assign Students to Class .......................................................

public ModelAndView AssignStudents() {
	return null;
}

}
