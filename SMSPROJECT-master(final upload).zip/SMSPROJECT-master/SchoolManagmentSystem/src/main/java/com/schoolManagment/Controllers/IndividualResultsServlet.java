package com.schoolManagment.Controllers;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.schoolManagment.Model.Student;
import com.schoolManagment.Services.ExaminationServiceInterface;
import com.schoolManagment.Services.ExaminationServicesImpl;

public class IndividualResultsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static int errorIndexNo = 0;
       
 
    public IndividualResultsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		final Logger logger = LoggerFactory.getLogger(IndividualResultsServlet.class);
		int indexNo = Integer.parseInt(request.getParameter("indexNoindi"));
		
		logger.info("///" + indexNo);
		
		Student student = new Student();
		ArrayList<Student> studentList1;
		
		student.setIndexNo(indexNo);
		
		ExaminationServiceInterface examinationIndi = new ExaminationServicesImpl();
		studentList1 = examinationIndi.getIndividualResults(student);
		
		double avgTerm1 = 0, avgTerm2 = 0, avgTerm3 = 0, term1 = 0, term2, term3, totTerm1 = 0, totTerm2 = 0, totTerm3 = 0;
		int count = 0;
		String temp1 = null, temp2 = null, temp3 = null;
		
		try {
			for (Student std : studentList1) {
				
				if(!std.getTerm1().matches("-?\\d+")) {
					temp1 = std.getTerm1();
					std.setTerm1("0");
				}
				else if(std.getTerm1().matches("-?\\d+")) {
					temp1 = std.getTerm1();
				}
				
				
				if(!std.getTerm2().matches("-?\\d+")) {
					temp2 = std.getTerm2();
					std.setTerm2("0");
				}
				else if(std.getTerm2().matches("-?\\d+")) {
					temp2 = std.getTerm2();
				}
				
				
				if(!std.getTerm3().matches("-?\\d+")) {
					temp3 = std.getTerm3();
					std.setTerm3("0");
				}
				else if(std.getTerm3().matches("-?\\d+")) {
					temp3 = std.getTerm3();
				}
								
				term1 = Double.parseDouble(std.getTerm1());
				term2 = Double.parseDouble(std.getTerm2());
				term3 = Double.parseDouble(std.getTerm3());
				
				totTerm1 = totTerm1 + term1;
				totTerm2 = totTerm2 + term2;
				totTerm3 = totTerm3 + term3;
				count++;
				
				std.setTerm1(temp1);
				std.setTerm2(temp2);
				std.setTerm3(temp3);
				
			}
			
			avgTerm1 = totTerm1 / count;
			avgTerm2 = totTerm2 / count;
			avgTerm3 = totTerm3 / count;
			
		} catch (NumberFormatException e) {
			logger.info("////NumberFormatException  ");
		}
		
		logger.info("////" + avgTerm1 + avgTerm2 + avgTerm3);
		
		
		
		
		request.setAttribute("studentList1", studentList1);
		request.setAttribute("indexNo", indexNo);
		
		try {
			request.setAttribute("name", studentList1.get(0).getName());
		} catch (Exception e) {
			errorIndexNo = 1;
			e.printStackTrace();
		}
		
		logger.info("*******************************"+errorIndexNo);
		
		request.setAttribute("average_term1", avgTerm1);
		request.setAttribute("average_term2", avgTerm2);
		request.setAttribute("average_term3", avgTerm3);
		
		if(errorIndexNo == 1){
			String not_found = "NOT FOUND IN OUR DB!";
			request.setAttribute("indexNo", not_found);
		}
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Examination/viewIndiResults");
		dispatcher.forward(request, response);
		
		
		
		
	}

}
