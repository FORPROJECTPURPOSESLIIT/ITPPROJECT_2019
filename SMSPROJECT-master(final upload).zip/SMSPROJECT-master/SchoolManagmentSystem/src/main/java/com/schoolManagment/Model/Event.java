package com.schoolManagment.Model;



public class Event {

	private String eventId;
	private String eName;
	private String eDate;
	private double cost;
	private double eIncome;
	private String empId;
	private String recordId;
	private String Description;
	
	public Event() {
		super();
	}

	public Event(String eventId) {
		super();
		this.eventId = eventId;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String geteName() {
		return eName;
	}

	public void seteName(String eName) {
		this.eName = eName;
	}

	public String geteDate() {
		return eDate;
	}

	public void seteDate(String eDate) {
		this.eDate = eDate;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public double geteIncome() {
		return eIncome;
	}

	public void seteIncome(double eIncome) {
		this.eIncome = eIncome;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getRecordId() {
		return recordId;
	}

	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	@Override
	public String toString() {
		return "Event [eventId=" + eventId + ", eName=" + eName + ", eDate=" + eDate + ", cost=" + cost + ", eIncome="
				+ eIncome + ", empId=" + empId + ", recordId=" + recordId + ", Description=" + Description + "]";
	}



	
	
	
	
}
