package com.schoolManagment.View;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Document;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.PdfWriter;
import com.schoolManagment.Model.ClassData;

public class PdfClassListReportView extends AbstractPdfView {

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		response.setHeader("Content-Disposition", "attachment; filename=\"class_list.pdf\"");
		
		
		@SuppressWarnings("unchecked")
		List<ClassData> list = (List<ClassData>) model.get("ClassList");
		
		Table table = new Table(4);
		table.addCell("CID");
		table.addCell("CLASS NAME");
		table.addCell("INVEN NO");
		table.addCell("TEACHER ID");
		
		for(ClassData data : list) {
			
			table.addCell(data.getCid());
			table.addCell(data.getcName());
			table.addCell(data.getToolNo());
			table.addCell(data.getEmpid());
			
		}
		document.add(table);
	}

}
