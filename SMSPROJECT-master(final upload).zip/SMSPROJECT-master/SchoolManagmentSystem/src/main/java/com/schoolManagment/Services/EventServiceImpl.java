package com.schoolManagment.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.schoolManagment.DAO.EventDao;
import com.schoolManagment.Model.Event;

@Service
public class EventServiceImpl implements EventService{
	
	EventDao eventDao;

	@Autowired
	public void setEventDao(EventDao eventDao) {
		this.eventDao = eventDao;
	}


	public List<Event> listAllEvents() {
		
		return eventDao.listAllEvents();
	}

	
	public void addEvent(Event event) {
		eventDao.addEvent(event);
		
	}

	
	public void updateEvent(Event event) {
		eventDao.updateEvent(event);
		
	}

	
	public void deleteEvent(String eventId) {
		eventDao.deleteEvent(eventId);
		
	}

	
	public Event findEventById(String eventId) {
		
		return eventDao.findEventById(eventId);  
	}

}
