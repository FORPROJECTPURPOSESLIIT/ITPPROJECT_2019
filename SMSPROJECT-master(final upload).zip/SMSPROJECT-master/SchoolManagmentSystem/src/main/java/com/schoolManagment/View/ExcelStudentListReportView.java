package com.schoolManagment.View;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsView;


import com.schoolManagment.Model.Student;

public class ExcelStudentListReportView extends AbstractXlsView{

	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		response.setHeader("content-Disposition","attachment:filename = \"student_list.xls\"");
		
		@SuppressWarnings("unchecked")
		List<Student> list = (List<Student>) model.get("StudentList");
		Sheet sheet = workbook.createSheet("Student list");
		
		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("IndexNo");
		header.createCell(1).setCellValue("name");
		header.createCell(2).setCellValue("gender");
		header.createCell(3).setCellValue("address");
		header.createCell(4).setCellValue("bday");
		
		int rowNum =1;
		
		for(Student student : list) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(student.getIndexNo());
			row.createCell(1).setCellValue(student.getName());
			row.createCell(2).setCellValue(student.getGender());
			row.createCell(3).setCellValue(student.getAddress());
			row.createCell(4).setCellValue(student.getBday());
			
			
			
			
			
		}
		
	
	}

}
