package com.schoolManagment.View;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsView;

 
import com.schoolManagment.Model.Transport;

public class ExcelTransportDetailListReportView extends AbstractXlsView{

	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
response.setHeader("Content-Disposition", "attachment; filename=\"transportDetails_list.xls\"");
		
		@SuppressWarnings("unchecked")
		List<Transport> list = (List<Transport>) model.get("transportDetails_list");
		
		Sheet sheet = workbook.createSheet("Transport Details List");
		  
		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("DRIVER ID");	
		header.createCell(1).setCellValue("DRIVER NAME");	
		header.createCell(2).setCellValue("VEHICLE ID");	
		header.createCell(3).setCellValue("DESCRIPTION");	
		header.createCell(4).setCellValue("DISTANCE");
		header.createCell(4).setCellValue("DATE");
		header.createCell(5).setCellValue("FEE");	
		
		int rowNum = 1;
		
		for( Transport transport : list ) {
			
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(transport.getDid());	
			row.createCell(1).setCellValue(transport.getDname());	
			row.createCell(2).setCellValue(transport.getVehicleID());	
			row.createCell(3).setCellValue(transport.getDescription());	
			row.createCell(4).setCellValue(transport.getDistance());
			row.createCell(4).setCellValue(transport.getTdate());
			row.createCell(5).setCellValue(transport.getFee());	
			
			
		}
		
		
	} 
		
	}

	
	
	
	

