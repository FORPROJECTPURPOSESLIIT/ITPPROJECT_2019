package com.schoolManagment.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.schoolManagment.Model.LoginData;
import com.schoolManagment.Services.DBConnection;

public class LoginDaoTest {
	
	Connection con = null;
	PreparedStatement ps ;
	

	public String validateEmployee(LoginData data) {
		
		String Email = data.getEmail();
		String Password = data.getPassword();
		
		String dbEmail = null;
		String dbPassword = null;
		
		
		try {
			con = DBConnection.getConnection();
			
			String Sql = "SELECT Email,Password FROM employee WHERE Email =?";
			ps = con.prepareStatement(Sql);
			ps.setString(1, Email);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				dbEmail = rs.getString("Email");
				dbPassword = rs.getString("Password");
			}
			
			if(dbEmail.equals(Email)&&dbPassword.equals(Password)) {
				return "success";
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return "error";
		
	}
	
	
}
