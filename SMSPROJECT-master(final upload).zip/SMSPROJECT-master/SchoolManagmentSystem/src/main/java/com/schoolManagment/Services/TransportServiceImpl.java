package com.schoolManagment.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.schoolManagment.DAO.TransportDao;
import com.schoolManagment.Model.Transport;


@Service
public class TransportServiceImpl implements TransportService {
	
	
	TransportDao transportDao;
	
	@Autowired
    public void setTransportDao(TransportDao transportDao) {
		this.transportDao = transportDao;
	}

	@Override
	public List<Transport> listAllTransport() {
		
		return transportDao.listAllTransport();
	}

	@Override
	public void addTransport(Transport transport) {
		
		transportDao.addTransport(transport);
		
	}

	@Override
	public void updateTransport(Transport transport) {
	
		transportDao.updateTransport(transport);
		
	}

	@Override
	public void deleteTransport(String did) {
		
		transportDao.deleteTransport(did);
		
	}

	@Override
	public Transport findTransportById(String did) {
		
		return transportDao.findTransportById(did);
	}
	
	
	
	
	
	

}
