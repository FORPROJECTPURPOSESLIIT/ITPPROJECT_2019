package com.schoolManagment.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterBatchUpdateUtils;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.schoolManagment.Model.Student;

@Repository
public class UserDaoImpl implements UserDao {

	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Autowired
	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) throws DataAccessException{
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}
	
	@Override
	public List<Student> list() {
		String sql = "SELECT * FROM student ";
		
		
		
		return null;
	}
	
	private SqlParameterSource getSqlParameterByModel(Student student) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource(); 
		return paramSource;
	}

	@Override
	public void AddUser(Student student) {
		// TODO Auto-generated method stub

	}

	@Override
	public void UpdateUser(Student student) {
		// TODO Auto-generated method stub

	}

	@Override
	public void DeleteUser(int index) {
		// TODO Auto-generated method stub

	}

	@Override
	public void findByUserID(int index) {
		// TODO Auto-generated method stub

	}

}
