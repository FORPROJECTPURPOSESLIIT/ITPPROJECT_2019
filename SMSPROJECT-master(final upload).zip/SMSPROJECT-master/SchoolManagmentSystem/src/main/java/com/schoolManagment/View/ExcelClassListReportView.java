package com.schoolManagment.View;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsView;

import com.schoolManagment.Model.ClassData;

public class ExcelClassListReportView  extends AbstractXlsView{

	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		response.setHeader("Content-Disposition", "attachment; filename=\"class_list.xls\"");
		
		@SuppressWarnings("unchecked")
		List<ClassData> list = (List<ClassData>) model.get("ClassList");
		
		Sheet sheet = workbook.createSheet("Class List");
		
		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("CID");
		header.createCell(1).setCellValue("CLASS NAME");
		header.createCell(2).setCellValue("INVEN NO");
		header.createCell(3).setCellValue("TEACHER ID");
		
		int rowNum = 1;
		
		for(ClassData data : list) {
			
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(data.getCid());
			row.createCell(1).setCellValue(data.getcName());
			row.createCell(2).setCellValue(data.getToolNo());
			row.createCell(3).setCellValue(data.getEmpid());
			
		}
		
	}

}
