package com.schoolManagment.Controllers;

import java.io.IOException;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.schoolManagment.Services.DBConnection;
import com.schoolManagment.Services.ExaminationServicesImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InsertTimeTable
 */

@MultipartConfig
public class InsertTimeTable extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Connection connection;

	private static Statement statement;

	private PreparedStatement preparedStatement;
       
	final Logger logger = LoggerFactory.getLogger(InsertTimeTable.class);

    public InsertTimeTable() {
        super();
        
    }
    
    @Bean(name = "filterMultipartResolver")
    public CommonsMultipartResolver multipartResolver() {
        CommonsMultipartResolver resolver = new CommonsMultipartResolver();
        resolver.setDefaultEncoding("utf-8");
        resolver.setMaxUploadSize(10000);
        return resolver;
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	       
	        String firstName = request.getParameter("firstName");
	        String lastName = request.getParameter("lastName");
	         
	        InputStream inputStream = null; 
	         
	     
	        Part filePart = request.getPart("photo");
	        if (filePart != null) {
	         
	            System.out.println(filePart.getName());
	            System.out.println(filePart.getSize());
	            System.out.println(filePart.getContentType());
	            logger.info("not nullllllllllllllllllllllllllllllllllllllllll");
	       
	            inputStream = filePart.getInputStream();
	        }
	        logger.info("*******************************************************");
	       
	        String message = null; 
	         
	        try {
	            
	        	DBConnection connect = new DBConnection();
				connection = connect.getConnection();
				
				statement = connection.createStatement();
	 
	          
	            String sql = "INSERT INTO `timetableimg` (`timetable`) VALUES (?)";
	            PreparedStatement statement = connection.prepareStatement(sql);
	             
	            if (inputStream != null) {
	              
	                statement.setBlob(1, inputStream);
	            }
	 
	         
	            statement.executeUpdate();
	            
	                message = "File uploaded and saved into database";
	            
	        } catch (SQLException ex) {
	            message = "ERROR: " + ex.getMessage();
	            ex.printStackTrace();
	        } finally {
	            if (connection != null) {
	               
	                try {
	                	connection.close();
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                }
	            }
	         
	           
	        }
	        
	        request.setAttribute("Message", message);
            getServletContext().getRequestDispatcher("/Examination/Message").forward(request, response);
	    }

}
