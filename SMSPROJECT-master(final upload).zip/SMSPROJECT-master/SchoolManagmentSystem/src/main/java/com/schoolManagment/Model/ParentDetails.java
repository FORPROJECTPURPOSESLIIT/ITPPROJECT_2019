package com.schoolManagment.Model;

public class ParentDetails {
	
	private String parentId;
    private String pName;
    private String bday;
    private String occupation;
    private String conatctNo;
    private String indexNo;
    
    
    
	public ParentDetails() {
		super();
	}
	public ParentDetails(String parentId) {
		super();
		this.parentId = parentId;
	}
	
	
	
	public ParentDetails(String parentId, String pName, String bday, String occupation, String conatctNo,
			String indexNo) {
		super();
		this.parentId = parentId;
		this.pName = pName;
		this.bday = bday;
		this.occupation = occupation;
		this.conatctNo = conatctNo;
		this.indexNo = indexNo;
	}
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getBday() {
		return bday;
	}
	public void setBday(String bday) {
		this.bday = bday;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getConatctNo() {
		return conatctNo;
	}
	public void setConatctNo(String conatctNo) {
		this.conatctNo = conatctNo;
	}
	public String getIndexNo() {
		return indexNo;
	}
	public void setIndexNo(String indexNo) {
		this.indexNo = indexNo;
	}
	@Override
	public String toString() {
		return "ParentDetails [parentId=" + parentId + ", pName=" + pName + ", bday=" + bday + ", occupation="
				+ occupation + ", conatctNo=" + conatctNo + ", indexNo=" + indexNo + "]";
	}
	
    
    
	
	
	

}
