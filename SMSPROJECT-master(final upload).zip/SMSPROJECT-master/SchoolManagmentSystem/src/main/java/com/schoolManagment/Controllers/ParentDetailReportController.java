package com.schoolManagment.Controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.schoolManagment.Model.ParentDetails;
import com.schoolManagment.Model.Transport;
import com.schoolManagment.Services.ParentDetailsService;
import com.schoolManagment.View.ExcelParentDetailListReportView;
import com.schoolManagment.View.PdfParentDetailsListReportView;

@Controller
@RequestMapping(value="/pdReport")
public class ParentDetailReportController {
	
	@Autowired
	ParentDetailsService parentDetailsService;

	@RequestMapping(value="/report", method=RequestMethod.GET)
	public ModelAndView parentDetailsListReport(HttpServletRequest req, HttpServletResponse res ) {
		
		String typeReport = req.getParameter("type"); 
		
		 
		
		 //List<ParentDetails> list1 = new ArrayList<ParentDetails>();
		 
		 List<ParentDetails> list1 = parentDetailsService.listAllParentDetails();
		 
		
		 
		/*  list1.add(new ParentDetails("parentId 1","pName 1", "bday 1", "occupation 1","conatctNo 1", "indexNo 1"));
		  list1.add(new ParentDetails("parentId 2","pName 2", "bday 2", "occupation 2","conatctNo 2", "indexNo 2"));
		  list1.add(new ParentDetails("parentId 3","pName 3", "bday 3", "occupation 3","conatctNo 3", "indexNo 3"));
		  list1.add(new ParentDetails("parentId 4","pName 4", "bday 4", "occupation 4","conatctNo 4", "indexNo 4"));
		  list1.add(new ParentDetails("parentId 5","pName 5", "bday 5", "occupation 5","conatctNo 5", "indexNo 5"));*/
		  
		  
		
		  if(typeReport != null && typeReport.equals("xls")){
			   return new ModelAndView(new ExcelParentDetailListReportView(), "parentDetails_list", list1);
			  } else if(typeReport != null && typeReport.equals("pdf")){
			   return new ModelAndView(new PdfParentDetailsListReportView(), "parentDetails_list", list1);
			  }
			  
			  return new ModelAndView("/parentDetailListReport", "parentDetails_list", list1);
			 }
		
	@RequestMapping(value="/abc", method= RequestMethod.GET)
	public ModelAndView list() {
		
		 ModelAndView model = new  ModelAndView("/parentDetailListReport");
		
		 
		 
		return model;
		
	}
		
		
		 
		
	}
	
	

