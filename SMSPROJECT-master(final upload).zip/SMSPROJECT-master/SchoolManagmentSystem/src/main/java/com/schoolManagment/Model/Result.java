package com.schoolManagment.Model;

public class Result {

	public String Id;
	private String email;
	private String password;

	public Result() {

	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	@Override
	public String toString() {
		return "Result [Id=" + Id + ", email=" + email + ", password=" + password + "]";
	}

}
