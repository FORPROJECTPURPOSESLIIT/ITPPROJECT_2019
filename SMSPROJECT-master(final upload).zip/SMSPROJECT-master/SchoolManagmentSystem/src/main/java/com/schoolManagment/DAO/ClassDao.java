package com.schoolManagment.DAO;

import java.util.List;

import com.schoolManagment.Model.ClassData;

public interface ClassDao {

	public List<ClassData> listAllClasses();
	
	public void addClass(ClassData data);
	
	public void updateClass(ClassData data);
	
	public void deleteClass(String cid);
	
	public ClassData findClassByID(String cid);
	
	public ClassData SearchClass(String cid);
}
