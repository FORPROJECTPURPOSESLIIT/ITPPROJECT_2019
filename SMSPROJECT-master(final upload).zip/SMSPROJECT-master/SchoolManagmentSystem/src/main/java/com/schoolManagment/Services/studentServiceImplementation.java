//package com.schoolManagment.Services;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.Statement;
//import java.util.ArrayList;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import com.schoolManagment.Model.Student;
//
//public class studentServiceImplementation implements studentServiceInterface{
//
//	
//	private static Connection connection;
//
//	private static Statement statement;
//
//	private PreparedStatement preparedStatement;
//	
//	final Logger logger = LoggerFactory.getLogger(studentServiceImplementation.class);
//	
//	public studentServiceImplementation() {
//		logger.info("invoked!!");
//	}
//	
//	
//	
//	@Override
//	public ArrayList<Student> getStudentDetails(Student student) {
//		
//		ArrayList<Student> studentList = new ArrayList<Student>();
//		
//		try {
//			
//			DBConnection connect = new DBConnection();
//			connection = connect.getConnection();
//			
//			statement = connection.createStatement();
//			
//			
//			String grade;
//			grade = student.getGrade();
//			logger.info(grade);
//			ResultSet resultset1 = statement.executeQuery("SELECT * FROM STUDENT WHERE CID = '"+ grade + "'");
//			
//			while (resultset1.next()) {
//				Student nStudent = new Student();
//				
//				nStudent.setIndexNo(resultset1.getInt(1));
//				nStudent.setName(resultset1.getString(2));
//				nStudent.setGender(resultset1.getString(3));
//				nStudent.setAddress(resultset1.getString(4));
//				nStudent.setBday(resultset1.getString(5));
//				nStudent.setPhone(resultset1.getString(6));
//				nStudent.setGrade(resultset1.getString(7));
//				nStudent.setDid(resultset1.getString(8));
//				nStudent.setIsbn(resultset1.getString(9));
//				studentList.add(nStudent);
//				
//				
//			}
//			
//
//			
//		} catch (Exception e) {
//			
//		}
//		return studentList;
//		
//	}
//		
//
//
//}
