package com.schoolManagment.Services;



import java.util.ArrayList;

import com.mysql.cj.jdbc.Blob;

import com.schoolManagment.Model.Student;


public interface ExaminationServiceInterface {
	
	public ArrayList<Student> getResults(Student student);
	
	public ArrayList<Student> getIndividualResults(Student student);

	public void updateClassResults(Student student);
	
	public void insertResults(Student student);

	public ArrayList<Student> getAllStudentResultList(Student student);

	public void update2ndtermResults(Student student);

	public void update3rdtermResults(Student student);
	
	public void deleteStudentResults(Student student);

}
