package com.schoolManagment.Controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.schoolManagment.DAO.ParentDetailsDaoImpl;

import com.schoolManagment.Model.ParentDetails;
import com.schoolManagment.Model.Transport;
import com.schoolManagment.Services.ParentDetailsService;

@Controller
@RequestMapping(value="/parentDetails")
public class ParentDetailsController {
	
	@Autowired
	ParentDetailsService parentDetailsService;
	
	@Autowired
	ParentDetailsDaoImpl parentDetailsDaoImpl;
	
	@RequestMapping(value="/list", method= RequestMethod.GET)
	public ModelAndView list() {
		
		 ModelAndView model = new  ModelAndView("parentDetails/parentDetails_list");
		
		 List<ParentDetails> list = parentDetailsService.listAllParentDetails();
		 model.addObject("listParentDetails", list);
		 
		return model;
		
	}
	
	@RequestMapping(value="/add", method= RequestMethod.GET)
	public ModelAndView add() {
		
		 ModelAndView model = new  ModelAndView("parentDetails/ParentDetails");
		
		 ParentDetails parentDetails = new ParentDetails();
		 model.addObject("parentDetailsForm", parentDetails);
		 
		return model;
		
	}
	
	@RequestMapping(value="/update/{parentId}", method= RequestMethod.GET)
	public ModelAndView update(@PathVariable("parentId") String parentId) {
		
		 ModelAndView model = new  ModelAndView("parentDetails/parentDetails_form");
		
		 ParentDetails parentDetails = parentDetailsService.findParentDetailsById(parentId);
		
		 model.addObject("parentDetailsForm", parentDetails);
		
		 
		return model;
		
	}
	
	@RequestMapping(value="/save", method= RequestMethod.POST)
	public ModelAndView save(@ModelAttribute("parentDetailsForm") ParentDetails parentDetails) {
		
		 
		
		 if(parentDetails != null && parentDetails.getParentId() != null) {
			 
			 //update
			 parentDetailsService.updateParentDetails(parentDetails);
			
			  }else {
				  
			 //add new
		     parentDetailsService.addParentDetails(parentDetails);
		
		 }
		 
		 return new ModelAndView("redirect:/parentDetails/list");
		}
	
	@RequestMapping(value="/insert", method= RequestMethod.POST)
	public ModelAndView insert(@ModelAttribute("parentDetailsForm") ParentDetails parentDetails) {
		
		 
		
		 if(parentDetails != null && parentDetails.getParentId() != null) {
			 
			 //update
			 parentDetailsService.addParentDetails(parentDetails);
			
			  }
		 
		 return new ModelAndView("redirect:/parentDetails/list");
		
		} 
	
	@RequestMapping(value="/delete/{parentId}", method= RequestMethod.GET)
	public ModelAndView delete(@PathVariable("parentId") String parentId) {
		
		
		 parentDetailsService.deleteParentDetails(parentId);
		
		 return new ModelAndView("redirect:/parentDetails/list");
		
	}

	@RequestMapping(value="/autoFill", method= RequestMethod.GET)
	public ModelAndView autoFill(ParentDetails parentDetails) {
		
		 ModelAndView model = new  ModelAndView("parentDetails/ParentDetails");
		 
		 parentDetails.setParentId("9123097");
		 parentDetails.setIndexNo("108");
		 parentDetails.setpName("Nethmi");
		 parentDetails.setBday("1999-08-25");
		 parentDetails.setOccupation("Doctor"); 
		 parentDetails.setConatctNo("0767945258");
		
		
		//parentDetailsService.addParentDetails(parentDetails);
		
		model.addObject("parentDetailsForm", parentDetails);
		return model;
		
	}
	
	
	
	

}
