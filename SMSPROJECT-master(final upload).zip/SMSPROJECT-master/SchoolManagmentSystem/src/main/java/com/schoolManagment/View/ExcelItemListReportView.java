package com.schoolManagment.View;

import java.util.Map;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsView;

import com.schoolManagment.Model.Item;

public class ExcelItemListReportView extends AbstractXlsView {

	@Override
	 protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			   HttpServletResponse response) throws Exception {
		
		response.setHeader("Content-disposition", "attachment; filename=\"item_list.xls\"");
		
		
		
		 @SuppressWarnings("unchecked")
		  List<Item> list = (List<Item>) model.get("itemList");
		  
		  Sheet sheet = workbook.createSheet("Item List");
		  
		  Row header = sheet.createRow(0);
		  header.createCell(0).setCellValue("TOOL NUMBER");
		  header.createCell(1).setCellValue("TOOL NAME");
		  header.createCell(2).setCellValue("QUANTITY");
		  header.createCell(3).setCellValue("DESCRIPTION");
		  header.createCell(3).setCellValue("INVENTORY TYPE");
		  
		  int rowNum = 1;
		  
		  for(Item item : list){
		   Row row = sheet.createRow(rowNum++);
		   row.createCell(0).setCellValue(item.getToolNo());
		   row.createCell(1).setCellValue(item.getToolName());
		   row.createCell(2).setCellValue(item.getQuantity());
		   row.createCell(3).setCellValue(item.getItemType());
		   row.createCell(4).setCellValue(item.getInvenType());
		  }
		
	}

}
