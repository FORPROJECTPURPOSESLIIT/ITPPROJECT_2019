package com.schoolManagment.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.schoolManagment.Model.Employee;
import com.schoolManagment.Services.EmployeeService;

@Controller
@RequestMapping(value = "/employee")
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {

		ModelAndView model = new ModelAndView("/Employee/employee_page");

		List<Employee> list = employeeService.listAllEmployees();
		model.addObject("listEmployees", list);

		return model;

	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView add() {

		ModelAndView model = new ModelAndView("/Employee/employee_form");

		Employee employee = new Employee();
		model.addObject("employeeform", employee);

		return model;

	}

	@RequestMapping(value = "/update/{empId}", method = RequestMethod.GET)
	public ModelAndView update(@PathVariable("empId") String empId) {

		ModelAndView model = new ModelAndView("/Employee/employeeUpdateForm");

		Employee employee = employeeService.findEmployeeById(empId);
		model.addObject("employeeform", employee);

		return model;
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView save(@ModelAttribute("employeeform") Employee employee) {
		
	
			employeeService.addEmployees(employee);
			
		return new ModelAndView("redirect:/employee/list");
	}
	@RequestMapping(value = "/updateEmp", method = RequestMethod.POST)
	public ModelAndView updateEmp(@ModelAttribute("employeeform") Employee employee) {
		
		
			employeeService.updateEmployees(employee);		
		
		
		return new ModelAndView("redirect:/employee/list");
	}

	@RequestMapping(value = "/delete/{empId}", method = RequestMethod.GET)
	public ModelAndView delete(@PathVariable("empId") String empId) {

		employeeService.deleteUser(empId);

		return new ModelAndView("redirect:/employee/list");
	}
	
	@RequestMapping(value = "/sal", method = RequestMethod.GET)
	public ModelAndView sal() {

		ModelAndView model = new ModelAndView("/Employee/EmployeeSalary");

		
	

		return model;

	}
	
	@RequestMapping(value = "/report", method = RequestMethod.GET)
	public ModelAndView report() {

		ModelAndView model = new ModelAndView("/Employee/empReport");

		
	

		return model;

	}
	
	
   @RequestMapping(value ="/search",method=RequestMethod.GET)
   public ModelAndView SearchEmployee(@ModelAttribute("listEmployees")Employee employee) {
	   
	   String empId = employee.getEmpId();
	   
	   Employee employee2 = employeeService.findEmployeeById(empId);
	   
	   ModelAndView model = new ModelAndView("/Employee/empSearch");
	   
	   model.addObject("searchEmp", employee2);
	   
	   return model;
   }
	
}