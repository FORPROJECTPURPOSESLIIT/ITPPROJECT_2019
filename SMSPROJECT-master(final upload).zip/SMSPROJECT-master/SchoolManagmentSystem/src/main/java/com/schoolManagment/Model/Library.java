package com.schoolManagment.Model;

public class Library {

	private String isbn;
	private String bname;
	//private int NoOfCopy;
	private String author;
	private String issuedDate;
	private String dateDue;

	public String getIssuedDate() {
		return issuedDate;
	}

	public void setIssuedDate(String issuedDate) {
		this.issuedDate = issuedDate;
	}

	public String getDateDue() {
		return dateDue;
	}

	public void setDateDue(String dateDue) {
		this.dateDue = dateDue;
	}

	public Library() {
		super();

	}

	public Library(String isbn) {
		super();
		this.isbn = isbn;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

//	public int getNoOfCopy() {
//		return NoOfCopy;
//	}
//
//	public void setNoOfCopy(int noOfCopy) {
//		NoOfCopy = noOfCopy;
//	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	@Override
	public String toString() {
		return "Library [isbn=" + isbn + ", bname=" + bname + ", author=" + author
				+ ", issuedDate=" + issuedDate + ", dateDue=" + dateDue + "]";
	}
	

}
