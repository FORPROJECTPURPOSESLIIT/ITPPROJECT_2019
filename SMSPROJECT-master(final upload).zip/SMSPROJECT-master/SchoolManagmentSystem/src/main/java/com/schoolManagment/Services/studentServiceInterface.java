package com.schoolManagment.Services;

import java.util.ArrayList;

import com.schoolManagment.Model.Student;

public interface studentServiceInterface {

	public ArrayList<Student> getStudentDetails(Student student);
}
