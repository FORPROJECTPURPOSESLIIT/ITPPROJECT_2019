package com.schoolManagment.Services;

import java.util.List;

import com.schoolManagment.Model.Employee;

public interface EmployeeService  {

	
	public List<Employee> listAllEmployees();

	public void addEmployees(Employee employee);
	
	public void updateEmployees(Employee employee);
	
	public void deleteUser(String empId);
	
	public Employee findEmployeeById(String empId);
}
