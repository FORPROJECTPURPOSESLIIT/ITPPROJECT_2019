package com.schoolManagment.Controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
@RequestMapping("/search")
public class SearchController {

	@RequestMapping(value="/homeSearch", method = RequestMethod.POST)
	public String homeSearch() {
		
		return "home";
		
	}
	
	
	
	
}
