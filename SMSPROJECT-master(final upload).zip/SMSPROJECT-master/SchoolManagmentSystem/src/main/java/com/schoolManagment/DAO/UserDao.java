package com.schoolManagment.DAO;

import java.util.List;

import com.schoolManagment.Model.Student;


public interface UserDao {

	public List<Student> list();
	
	public void AddUser(Student student);
	
	public void UpdateUser(Student student);
	
	public void DeleteUser(int index);
	
	public void findByUserID(int index);
	
}
