package com.schoolManagment.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.schoolManagment.Model.Item;

@Repository
public class ItemDaoImpl implements ItemDao {

	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Autowired
	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		  this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
		 }
	
	
	public List<Item> listAllItems() {
		String sql = "SELECT  toolNo,toolName,quantity,itemType,invenType from inventory";
		List<Item> list = namedParameterJdbcTemplate.query(sql, getSqlParameterByModel(null), new ItemMapper());
		return list;
	}

	private SqlParameterSource getSqlParameterByModel(Item item)
	{
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		
		if(item !=null)
		{
			paramSource.addValue("toolNo", item.getToolNo());
			paramSource.addValue("toolName", item.getToolName());
			paramSource.addValue("quantity", item.getQuantity());
			paramSource.addValue("itemType", item.getItemType());
			paramSource.addValue("invenType", item.getInvenType());
		}
		return paramSource;
	}
	
	private static final class ItemMapper implements RowMapper<Item>
	{
		public Item mapRow(ResultSet rs, int rowNum)throws SQLException
		{
			Item item = new Item();
			item.setToolNo(rs.getString("toolNo"));
			item.setToolName(rs.getString("toolName"));
			item.setQuantity(rs.getString("quantity"));
			item.setItemType(rs.getString("itemType"));
			item.setInvenType(rs.getString("invenType"));
			
			return item;
		}
	}
	
	
	public void addItem(Item item) {
		try {
			System.out.println("In update item. itemDao impl");
			String sql = "INSERT INTO inventory(toolNo,toolName,quantity,itemType,invenType) VALUES (:toolNo, :toolName, :quantity, :itemType,:invenType )";
			
			namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(item));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

	
	public void updateItem(Item item) {
		
		String sql = "UPDATE inventory SET  toolName = :toolName, quantity = :quantity, itemType = :itemType, invenType = :invenType WHERE toolNo = :toolNo";
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(item));
	}

	
	public void deteteItem(String toolNo) {
		String sql = "DELETE FROM inventory where toolNo = :toolNo";
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(new Item(toolNo)));
		
	}

	
	public Item findItemById(String toolNo) {
		String sql = "SELECT * FROM inventory where toolNo= :toolNo";
		return namedParameterJdbcTemplate.queryForObject(sql, getSqlParameterByModel(new Item(toolNo)), new ItemMapper());
	}
	
/////////// ............... List all inventory data for class ............................	
	
@Override
public List<Item> ListAllClassItems(String toolNo) {
	String sql = "SELECT * FROM inventory where toolNo= :toolNo";
//	List<Item> list =  namedParameterJdbcTemplate.queryForObject(sql, getSqlParameterByModel(new Item(toolNo)), new ItemMapper());
	List<Item> list =  namedParameterJdbcTemplate.query(sql, getSqlParameterByModel(new Item(toolNo)), new ItemMapper());
	return list;
}

}
