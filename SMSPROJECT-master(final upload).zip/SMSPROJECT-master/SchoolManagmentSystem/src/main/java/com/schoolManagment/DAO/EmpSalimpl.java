package com.schoolManagment.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.schoolManagment.Model.EmpSal;


@Repository
public class EmpSalimpl implements EmpsalDao{
	
	
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Autowired
	
	public void setNamedParmeterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate)throws DataAccessException{
		
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
		
	}
	
	


	public List<EmpSal> listAllEmpSal() {
		
		String sql ="SELECT * FROM nonacademic";
		
		List<EmpSal> list = namedParameterJdbcTemplate.query(sql, getSqlParmeterByModel(null), new EmpSalMapper());
		return list;
	}
	
	
	private SqlParameterSource getSqlParmeterByModel(EmpSal empsal) {
		
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		if(empsal != null) {
			paramSource.addValue("empId", empsal.getEmpId());
			paramSource.addValue("salary", empsal.getSalary());

		}
		return paramSource;
	}
	
	
	private static final class EmpSalMapper implements RowMapper<EmpSal>{
		
		public EmpSal mapRow(ResultSet rs,int rowNum)throws SQLException{
			EmpSal empsal = new EmpSal();
			empsal.setEmpId(rs.getString("empId"));
			empsal.setSalary(rs.getDouble("salary"));
			return empsal;
		}
	}


	public void addEmpSal(EmpSal empsal) {

			String sql = "INSERT INTO `nonacademic` (`empId`, `salary`) VALUES (:empId, :salary)";
			
			namedParameterJdbcTemplate.update(sql, getSqlParmeterByModel(empsal));
			
	}
	
	
	public void updateEmpSal(EmpSal empsal) {

		String sql = "UPDATE nonacademic SET empId=:empId,salary =:salary";
		
		namedParameterJdbcTemplate.update(sql, getSqlParmeterByModel(empsal));

	}

	
	public void deleteEmpSal(String empId) {

		String sql = "DELETE FROM nonacademic WHERE empId=:empId";
		
		namedParameterJdbcTemplate.update(sql, getSqlParmeterByModel(new EmpSal(empId)));

	}

	
	public EmpSal findEmpSalById(String empId) {
		
		String sql = "SELECT * FROM nonacademic WHERE empId=:empId";
		
		
		return namedParameterJdbcTemplate.queryForObject(sql, getSqlParmeterByModel(new EmpSal(empId)), new EmpSalMapper());
	}

}
