package com.schoolManagment.DAO;

import java.sql.ResultSet;


import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.schoolManagment.Model.ClassData;

@Repository
public class ClassDaoImpl implements ClassDao {
	
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Autowired
	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		  this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
		 }

	public List<ClassData> listAllClasses() {
		String sql = "SELECT cid,toolNo,cName,empid FROM class";
		List<ClassData> list = namedParameterJdbcTemplate.query(sql, getSqlParameterByModel(null), new ClassMapper());
		return list;

	}
	
	private SqlParameterSource getSqlParameterByModel(ClassData data) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		if(data != null) {
			paramSource.addValue("cid", data.getCid());
			paramSource.addValue("cName", data.getcName());
			paramSource.addValue("empid", data.getEmpid());
			paramSource.addValue("toolNo", data.getToolNo());
			
		}
		
		return paramSource;
	}
	
private static final class ClassMapper implements RowMapper<ClassData>{
		
		public ClassData mapRow(ResultSet rs, int rowNum) throws SQLException{
			ClassData data = new ClassData();
			data.setCid(rs.getString("cid"));
			data.setcName(rs.getString("cName"));
			data.setEmpid(rs.getString("empid"));
			data.setToolNo(rs.getString("toolNo"));
			
			return data;
			
		}
		
	}

	
	public void addClass(ClassData data) {
		
		System.out.println("in classDaoImpl addClass"+data.getEmpid());
//		String sql = "INSERT INTO class(`cId`, `toolNo`, `cName`) VALUES (:cid,:toolNo,:cName)";
		String sql =  "INSERT INTO class(`cId`, `toolNo`, `cName`, `empid`) VALUES (:cid,:toolNo,:cName, :empid)";
		

		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(data));
		
	}

	
	public void updateClass(ClassData data) {
		System.out.println("in classDaoImpl update"+data);
		String sql = "UPDATE class SET  cName = :cName , toolNo = :toolNo , empid = :empid where cId = :cid";
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(data));
	}

	
	public void deleteClass(String cid) {
		
		String sql = "DELETE FROM class WHERE cid = :cid";
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(new ClassData(cid)));
		
	}

	
	public ClassData findClassByID(String cid) {
		
		String sql = "SELECT * FROM class WHERE cid = :cid";
		return namedParameterJdbcTemplate.queryForObject(sql, getSqlParameterByModel(new ClassData(cid)), new ClassMapper());
	}

	@Override
	public ClassData SearchClass(String cid) {
		String sql = "SELECT * FROM class WHERE cid = :cid";
		return namedParameterJdbcTemplate.queryForObject(sql, getSqlParameterByModel(new ClassData(cid)), new ClassMapper());
	}

}
