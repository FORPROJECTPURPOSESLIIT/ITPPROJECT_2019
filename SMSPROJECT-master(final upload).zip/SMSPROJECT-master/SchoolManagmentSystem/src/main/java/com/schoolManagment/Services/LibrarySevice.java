package com.schoolManagment.Services;

import java.util.List;

import com.schoolManagment.Model.Library;

public interface LibrarySevice {

	public List<Library> bookList();

	public List<Library> issueBookList();
	
	public List<Library> viewBookListUsers();
	
	public void addBookLibrary(Library library);

	public void updateBookLibrary(Library library);

	public void deleteBookLibrary(String isbn);

	public Library findBookByID(String isbn);
	
	public void issueBookLibrary(Library library);

}
