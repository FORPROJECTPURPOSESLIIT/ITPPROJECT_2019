package com.schoolManagment.View;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsView;

import com.schoolManagment.Model.Library;

public class ExcelViewListReportView extends AbstractXlsView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		response.setHeader("Content-disposition", "attachment; filename=\"view_list.xls\"");

		@SuppressWarnings("unchecked")
		List<Library> list = (List<Library>) model.get("viewlist");
		
		Sheet sheet  = workbook.createSheet("Library library");
		
		//header row
		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("ISBN");
		header.createCell(1).setCellValue("BOOK NAME");
		header.createCell(2).setCellValue("AUTHOR");
		//header.createCell(3).setCellValue("ISSUE DATE");
		//header.createCell(4).setCellValue("WHEN TO RETURN");
		
		
		int rowNum = 1;
		
		for(Library library : list) {
			
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(library.getIsbn());
			row.createCell(1).setCellValue(library.getBname());
			row.createCell(2).setCellValue(library.getAuthor());
			//row.createCell(3).setCellValue(library.getIssuedDate());
			//row.createCell(4).setCellValue(library.getDateDue());
			
		}
	}

}
