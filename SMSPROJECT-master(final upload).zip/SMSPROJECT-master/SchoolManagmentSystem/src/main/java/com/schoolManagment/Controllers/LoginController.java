package com.schoolManagment.Controllers;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.schoolManagment.DAO.LoginDaoTest;
import com.schoolManagment.Model.LoginData;


@Controller
@RequestMapping("/login")
public class LoginController {
	
	@RequestMapping(value="/loginto" , method =RequestMethod.POST)
	public ModelAndView login(@ModelAttribute("LoginData") LoginData data) {
		
		LoginDaoTest loginTest = new LoginDaoTest();
		
		String str = loginTest.validateEmployee(data);
		
		if(str.equals("success")) {
			return new ModelAndView("redirect:/admin/display");
		}
		
		
		return  new ModelAndView("redirect:/admin/error");
		
		
		
	}
}
