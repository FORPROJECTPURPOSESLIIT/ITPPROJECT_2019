package com.schoolManagment.Model;

public class LoginData {

	private String Email;
	private String Password;
	private String Type;
	
	public LoginData(String email) {
		super();
		Email = email;
	}

	public LoginData() {
		super();
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	@Override
	public String toString() {
		return "LoginData [Email=" + Email + ", Password=" + Password + ", Type=" + Type + "]";
	}
	
	
	
	
	
}
