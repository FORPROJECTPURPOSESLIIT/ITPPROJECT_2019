package com.schoolManagment.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.schoolManagment.DAO.LibraryDao;
import com.schoolManagment.Model.Library;

@Service
public class LibraryServiceImpl implements LibrarySevice{
	
	LibraryDao libraryDao;
	
	@Autowired
	public void setLibraryDao(LibraryDao libraryDao) {
		this.libraryDao = libraryDao;
	}

	
	public List<Library> bookList() {
		return libraryDao.bookList();
	}
	
	public List<Library> issueBookList(){
		return libraryDao.issueBookList();
	}

	
	public void addBookLibrary(Library library) {
		libraryDao.addBookLibrary(library);
		
	}

	
	public void updateBookLibrary(Library library) {
		libraryDao.updateBookLibrary(library);
		
	}

	
	public void deleteBookLibrary(String isbn) {
		libraryDao.deleteBookLibrary(isbn);
		
	}

	
	public Library findBookByID(String isbn) {

		return libraryDao.findBookByID(isbn);
	}
	
	public void issueBookLibrary(Library library) {
		libraryDao.issueBookLibrary(library);
	}


	@Override
	public List<Library> viewBookListUsers() {
		return libraryDao.viewBookListUsers();
	}

}
