package com.schoolManagment.Services;

import java.util.List;

import com.schoolManagment.Model.EmpSal;


	public interface EmpSalService {
	
	public List<EmpSal> listAllEmpSal();
	
	public void addEmpSal(EmpSal empsal);
	
	public void updateEmpSal(EmpSal empsal);
	
	public void deleteEmpSal(String empId);
	
	public EmpSal findEmpSalById(String empId);

}
