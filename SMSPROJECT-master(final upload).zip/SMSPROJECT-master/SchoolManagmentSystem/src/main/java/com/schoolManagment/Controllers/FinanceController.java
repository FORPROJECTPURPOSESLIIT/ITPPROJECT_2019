package com.schoolManagment.Controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.schoolManagment.Model.Event;
import com.schoolManagment.Model.Finance;
import com.schoolManagment.Services.FinanceService;

import com.schoolManagment.View.ExcelViewListReportView;
import com.schoolManagment.View.PdfViewListReportView;

@Controller
@RequestMapping(value = "/finance")
public class FinanceController {

	@Autowired
	FinanceService financeService;

	// .................................................. view the database records
	// ..............................
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {

		Finance finance = new Finance();

		ModelAndView model = new ModelAndView("/Finance/Finance");

		List<Finance> list = financeService.listAllFinance();
		model.addObject("FinanceList", list);

		return model;
	}

	// ........................................ calling the add function and
	// redirect to addClass.jsp ...................................

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView add() {

		ModelAndView model = new ModelAndView("/Finance/AddNewFinance");

		Finance finance = new Finance();
		model.addObject("AddFinance", finance); // creating a binding model attribute

		return model;
	}

	// ...........................................view the updating the records page
	// .............................................

	@RequestMapping(value = "/update/{recordId}", method = RequestMethod.GET)
	public ModelAndView update(@PathVariable("recordId") String recordId) {
		System.out.println(recordId);
		ModelAndView model = new ModelAndView("/Finance/updateFinance");

		Finance finance = financeService.findFinanceByID(recordId);
		model.addObject("AddFinance", finance);
		return model;
	}

	// ............................. fetching the data from form to
	// database..........................................................

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView save(@Valid @ModelAttribute("AddClass") Finance finance, BindingResult result) {

		financeService.updateFinance(finance);

		System.out.println(finance);
		return new ModelAndView("redirect:/finance/list");
	}

	// ...................... fetching updated data
	// .....................................................................

	@RequestMapping(value = "/fetch", method = RequestMethod.POST)
	public ModelAndView addNew(@Valid @ModelAttribute("AddClass") Finance finance, BindingResult result) {

		financeService.addFinance(finance);

		System.out.println(finance);
		return new ModelAndView("redirect:/finance/list");
	}

	// ........................ Delete function
	// ..............................................................................

	@RequestMapping(value = "/delete/{recordId}", method = RequestMethod.GET)
	public ModelAndView delete(@PathVariable("recordId") String recordId) {

		financeService.deleteFinance(recordId);

		return new ModelAndView("redirect:/finance/list");
	}

//...............search............................................

@RequestMapping(value = "/searchFinance", method = RequestMethod.GET)
public ModelAndView searchFinanceInfo(@ModelAttribute("FinanceList")Finance finance) {
	
	String recordId = finance.getRecordId();
	
	Finance searchlistFinance = financeService.findFinanceByID(recordId);
	ModelAndView model = new ModelAndView("/Finance/SearchFinance");
	model.addObject("searchFinanceResult", searchlistFinance);
	
	return model;
}
//report

@RequestMapping(value="/report", method=RequestMethod.GET)
public ModelAndView Finance(HttpServletRequest req, HttpServletResponse res) {
	
	String typeReport =  req.getParameter("type");
	
	List<Finance> list = financeService.listAllFinance();
	
	if(typeReport != null && typeReport.equals("xls")) {
		
		return new ModelAndView(new ExcelViewListReportView(), "viewlist", list);
	
	}else if(typeReport != null && typeReport.equals("pdf")){
		
		return new ModelAndView(new PdfViewListReportView(), "viewlist", list);
	}
	
	return new ModelAndView("Finance","viewlist" ,list);
}

}