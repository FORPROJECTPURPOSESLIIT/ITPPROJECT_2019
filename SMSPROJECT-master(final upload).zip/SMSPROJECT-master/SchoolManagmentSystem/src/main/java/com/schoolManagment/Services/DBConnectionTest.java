package com.schoolManagment.Services;
import java.sql.*;

public class DBConnectionTest
{
	public static void main(String [] args) throws SQLException
	{
		Connection conn = DBConnection.getConnection();
		int indexNo = 1999000001;
		try
		{
			String query = "SELECT st.indexNo, st.sid, s.name, st.term1\r\n" + 
					"FROM student_subject st, student s\r\n" + 
					"WHERE st.indexNo = s.indexNo AND st.indexNo = '"+ indexNo + "' ";
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(query);
			
			while(rst.next())
			{
				System.out.println(rst.getString(1)+"	"+ rst.getString(2)+"		"+ rst.getString(3)+"	"+ rst.getString(4)+"	");	
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}finally
		{
			try{
				conn.close();
			}catch(SQLException ex)
			{
				ex.printStackTrace();
			}
		}
		
	}
}