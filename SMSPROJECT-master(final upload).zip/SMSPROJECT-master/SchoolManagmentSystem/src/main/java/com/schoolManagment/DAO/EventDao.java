package com.schoolManagment.DAO;

import java.util.List;

import com.schoolManagment.Model.Event;

public interface EventDao {

	public List<Event> listAllEvents();
	
	public void addEvent(Event event);
	
	public void updateEvent(Event event);
	
	public void deleteEvent(String eventId);

	public Event findEventById(String eventId);
	
	
}
