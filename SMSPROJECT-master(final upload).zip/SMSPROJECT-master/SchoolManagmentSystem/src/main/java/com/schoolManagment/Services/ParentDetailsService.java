package com.schoolManagment.Services;

import java.util.List;

import com.schoolManagment.Model.ParentDetails;

public interface ParentDetailsService {


    public List<ParentDetails> listAllParentDetails();
	
	public void addParentDetails(ParentDetails parentDetails);
	
	public void updateParentDetails(ParentDetails parentDetails);
	
	public void deleteParentDetails(String parentId);
	
	public ParentDetails findParentDetailsById(String parentId);
	
	
	
	
	
	
}
