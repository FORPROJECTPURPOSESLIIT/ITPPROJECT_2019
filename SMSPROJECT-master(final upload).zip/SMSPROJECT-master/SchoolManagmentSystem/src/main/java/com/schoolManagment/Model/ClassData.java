package com.schoolManagment.Model;

import org.hibernate.validator.constraints.NotEmpty;

public class ClassData {
	@NotEmpty(message="Class id cannot be null")
	private String cid;
	
	private String cName;
	
	private String toolNo;
	private String empid;
	
	
	public ClassData() {
		super();
	}
	public ClassData(String cid) {
		super();
		this.cid = cid;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	
	public String getToolNo() {
		return toolNo;
	}
	public void setToolNo(String toolNo) {
		this.toolNo = toolNo;
	}
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	@Override
	public String toString() {
		return "ClassData [cid=" + cid + ", cName=" + cName + ", toolNo=" + toolNo
				+ ", empid=" + empid + "]";
	}
	
	
}
