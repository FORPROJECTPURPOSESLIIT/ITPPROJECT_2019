package com.schoolManagment.View;


import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.schoolManagment.Model.Student;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Document;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.PdfWriter;

public class PdfStudentListReportView extends AbstractPdfView {

 @Override
 protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer, HttpServletRequest request,
   HttpServletResponse response) throws Exception {
  
  response.setHeader("Content-Disposition", "attachment; filename=\"student_list.pdf\"");
  
  @SuppressWarnings("unchecked")
  List<Student> list = (List<Student>) model.get("studentList");
  
  Table table = new Table(4);
  table.addCell("IndexNo");
  table.addCell("name");
  table.addCell("gender");
  table.addCell("address");
  table.addCell("bday");
  
  for(Student student : list){
   table.addCell(String.valueOf(student.getIndexNo()));
   table.addCell(student.getName());
   table.addCell(student.getGender());
   table.addCell(student.getAddress());
   table.addCell(student.getBday());
  }
  
  document.add(table);
 }}

