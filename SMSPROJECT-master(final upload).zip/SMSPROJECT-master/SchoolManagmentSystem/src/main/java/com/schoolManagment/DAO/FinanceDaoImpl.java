package com.schoolManagment.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.schoolManagment.Model.Finance;
@Repository
public class FinanceDaoImpl implements FinanceDao {
	
NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Autowired
	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		  this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
		 }

	@Override
	public List<Finance> listAllFinance() {
		
		String sql = "SELECT recordId,sponserDetails,expenditure,income,description  FROM finance";
		List<Finance> list = namedParameterJdbcTemplate.query(sql, getSqlParameterByModel(null), new FinanceMapper());
		return list;
	}
	
	private SqlParameterSource getSqlParameterByModel(Finance finance) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		if(finance != null) {
			paramSource.addValue("recordId", finance.getRecordId());
			paramSource.addValue("sponserDetails",finance.getSponserDetails());
			paramSource.addValue("expenditure", finance.getExpenditure());
			paramSource.addValue("income", finance.getIncome());
			paramSource.addValue("description", finance.getDescription());
			
		}
		
		return paramSource;
	}
	
private static final class FinanceMapper implements RowMapper<Finance>{
		
		public Finance mapRow(ResultSet rs, int rowNum) throws SQLException{
			Finance finance = new Finance();
			finance.setRecordId(rs.getString("recordId"));
			finance.setSponserDetails(rs.getString("sponserDetails"));
			finance.setExpenditure(rs.getDouble("expenditure"));
			finance.setIncome(rs.getDouble("income"));
			finance.setDescription(rs.getString("description"));
			
			return finance;
			
		}
		
	}


	@Override
	public void addFinance(Finance finance) {
		String sql = "INSERT INTO finance (`recordId`, `sponserDetails`, `expenditure`, `income`, `description`) VALUES (:recordId,:sponserDetails,:expenditure,:income,:description)";
		
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(finance));
		
	}

	@Override
	public void updateFinance(Finance finance) {
		String sql = "UPDATE finance SET sponserDetails = :sponserDetails , expenditure = :expenditure , income = :income, description = :description WHERE  recordId = :recordId";
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(finance));
		
	}

	@Override
	public void deleteFinance(String recordId) {
		String sql = "DELETE FROM finance WHERE recordId = :recordId";
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(new Finance(recordId)));
		
	}

	@Override
	public Finance findFinanceByID(String recordId) {
		
		String sql = "SELECT  recordId,sponserDetails,expenditure,income,description FROM finance WHERE recordId = :recordId";
		return namedParameterJdbcTemplate.queryForObject(sql, getSqlParameterByModel(new Finance(recordId)), new FinanceMapper());
	}
//	
//	public Finance findFinanceByID(String recordId) {
//		String sql = "SELECT "
//	}

}
