package com.schoolManagment.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.schoolManagment.Model.Student;
@Repository
public class StudentDaoImpl implements StudentDAO {
	
	
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}
	
	
	@Override
	public List<Student> listAllStudents() {
		
		String sql="SELECT indexNo,name,gender,address,bday,phone FROM student";
		
		List<Student> list = namedParameterJdbcTemplate.query(sql, getSqlParameterByModel(null), new StudentMapper());
		
		return list;
	}

	private SqlParameterSource getSqlParameterByModel(Student student) {
		MapSqlParameterSource String = new MapSqlParameterSource();
		if(student != null ) {
			String.addValue("indexNo", student.getIndexNo());
			String.addValue("name", student.getName());
			String.addValue("gender", student.getGender());
			String.addValue("address", student.getAddress());
			String.addValue("bday", student.getBday());
			String.addValue("phone", student.getPhone());
			/* paramSource.addValue("cid", student.getCid()); */
			/*
			 * paramSource.addValue("did", student.getDid()); paramSource.addValue("isbn",
			 * student.getIsbn());
			 */
			
			
			
			
		}
		return String;
	}
	
	private static final class StudentMapper implements RowMapper<Student>{
		
		public Student mapRow(ResultSet rs, int rowNum) throws SQLException{
			Student student = new Student();
			
			student.setIndexNo(rs.getInt("indexNo"));
			student.setName(rs.getString("name"));
			student.setGender(rs.getString("gender"));
			student.setAddress(rs.getString("address"));
			student.setBday(rs.getString("bday"));
			student.setPhone(rs.getInt("phone"));
			/*
			 * student.setCid(rs.getString("cid")); student.setDid(rs.getString("did"));
			 * student.setIsbn(rs.getString("isbn"));
			 */
			
			return student;
		}		
		
	}
	
	
	@Override
	public void AddStudent(Student student) {
		System.out.println("imfrom student dao add");
		String sql="INSERT INTO student(indexNo,name,gender,address,bday,phone)VALUES(:indexNo,:name,:gender,:address,:bday,:phone)";
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(student));
		
		
	}

	@Override
	public void UpdateStudent(Student student) {
		
		String sql="UPDATE student SET  name=:name,gender=:gender,address=:address,bday=:bday,phone=:phone WHERE indexNo=:indexNo";
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(student));
		
	}

	@Override
	public void DeleteStudent(int indexNo) {
		
		String sql = "DELETE FROM student WHERE indexNo = :indexNo";
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(new Student(indexNo)));
		
		
	}

	@Override
	public Student findStudentById(int indexNo) {
		
		String sql="SELECT indexNo,name,gender,address,bday,phone FROM student WHERE indexNo = :indexNo  ";
		return namedParameterJdbcTemplate.queryForObject(sql, getSqlParameterByModel(new Student(indexNo)), new StudentMapper());
	}

}
