package com.schoolManagment.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.schoolManagment.DAO.ItemDao;
import com.schoolManagment.Model.Item;

@Service
public class ItemServiceImpl implements ItemService {

	ItemDao itemDao;
	
	@Autowired
	public void setItemDao(ItemDao itemDao)
	{
		this.itemDao=itemDao;
	}
	
	
	public List<Item> ListAllItems() {
	
		return itemDao.listAllItems();
	}

	
	public void addItems(Item item) {
		itemDao.addItem(item);
		
	}

	
	public void updateItems(Item item) {
		itemDao.updateItem(item);
		
	}

	
	public void deleteItems(String toolNo) {
		itemDao.deteteItem(toolNo);
		
	}

	
	public Item findItemById(String toolNo) {
		return itemDao.findItemById(toolNo);
		
	}
	
	@Override
	public List<Item> ListAllClassItems(String tooNo) {
		
		return itemDao.ListAllClassItems(tooNo);
	}


}
