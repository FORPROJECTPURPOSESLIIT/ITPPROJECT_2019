package com.schoolManagment.View;


import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Document;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.PdfWriter;
import com.schoolManagment.Model.Item;



public class PdfItemListReportView extends AbstractPdfView {

	 

	@Override
	 protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer, HttpServletRequest request,
	   HttpServletResponse response) throws Exception {
	  
	  response.setHeader("Content-Disposition", "attachment; filename=\"item_list.pdf\"");
	  
	  @SuppressWarnings("unchecked")
	  List<Item> list = (List<Item>) model.get("itemList");
	  
	  Table table = new Table(5);
	  table.addCell("TOOL NUMBER");
	  table.addCell("TOOL NAME");
	  table.addCell("QUANTITY");
	  table.addCell("DESCRIPTION");
	  table.addCell("INVENTORY TYPE");
	  
	  for(Item item : list){
	   table.addCell(item.getToolNo());
	   table.addCell(item.getToolName());
	   table.addCell(item.getQuantity());
	   table.addCell(item.getItemType());
	   table.addCell(item.getInvenType());
	  }
	  
	  document.add(table);
	 }
	 
	
}
