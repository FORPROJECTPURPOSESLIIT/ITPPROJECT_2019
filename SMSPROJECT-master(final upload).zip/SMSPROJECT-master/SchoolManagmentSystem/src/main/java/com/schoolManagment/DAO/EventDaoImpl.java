package com.schoolManagment.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.schoolManagment.Model.Event;



@Repository

public class EventDaoImpl implements EventDao{ 
	
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Autowired
	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) throws DataAccessException{
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;	
    }

	
	public List<Event> listAllEvents() {
		String sql = "SELECT eventId, eName, eDate, cost, eIncome, empId, recordId, Description FROM `event`";
		List<Event> list = namedParameterJdbcTemplate.query(sql, getSqlParameterByModel(null), new EventMapper());
		
		
		return list;
	}
	
	private SqlParameterSource getSqlParameterByModel(Event event) {
		
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		if(event != null) {
			paramSource.addValue("eventId",event.getEventId());
			paramSource.addValue("eName", event.geteName());
			paramSource.addValue("eDate", event.geteDate());
			paramSource.addValue("cost", event.getCost());
			paramSource.addValue("eIncome", event.geteIncome());
			paramSource.addValue("empId", event.getEmpId());
			paramSource.addValue("recordId", event.getRecordId());
			paramSource.addValue("Description", event.getDescription());	
			
		}
		
		return paramSource;
	}
	
	
	private static final class EventMapper implements RowMapper<Event>{
		
		public Event mapRow(ResultSet rs, int rowNum) throws SQLException{	
			Event event = new Event();
			event.setEventId(rs.getString("eventId"));
			event.seteName(rs.getString("eName"));
			event.seteDate(rs.getString("eDate"));
			event.setCost(rs.getDouble("cost"));
			event.seteIncome(rs.getDouble("eIncome"));
			event.setEmpId(rs.getString("empId"));
			event.setRecordId(rs.getString("recordId"));
			event.setDescription(rs.getString("Description"));
			//event.setDescription(rs.getString("Description"));
			//event.setDescription(rs.getString("Description"));
			
			return event;
			
		}
	}

	
	public void addEvent(Event event) {
		System.out.println("addEvent deo impl"+event);
		//String sql = "INSERT INTO event(eventId, eName, eDate, Description,)VALUES (':eventId',':eName',':eDate',':Description')";
		String sql = "INSERT INTO event (`eventId`, `eName`, `eDate`, `cost`, `eIncome`, `empId`, `recordId`,`Description`) VALUES (:eventId,:eName,:eDate,:cost,:eIncome,:empId,:recordId,:Description)";
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(event));
	}

	
	public void updateEvent(Event event) {
		String sql = "UPDATE  event SET  eName = :eName, eDate = :eDate, cost = :cost, eIncome = :eIncome, empId = :empId, recordId = :recordId, Description = :Description WHERE eventId = :eventId ";
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(event));
		
	}

	
	public void deleteEvent(String eventId) {
		String sql = "DELETE FROM event WHERE eventId = :eventId";
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(new Event(eventId)));
	}

	
	public Event findEventById(String eventId) {
		String sql = "SELECT * FROM event WHERE eventId = :eventId";
		
		return namedParameterJdbcTemplate.queryForObject(sql, getSqlParameterByModel(new Event(eventId)), new EventMapper());
	}
	
	

}
