package com.schoolManagment.Model;

public class Item {

	private String toolNo;
	private String toolName;
	private String quantity;
	private String itemType;
	private String invenType;
	
	public Item()
	{
		super();
	}
	
	public Item (String toolNo)
	{
		super();
		this.toolNo=toolNo;
	}
	
	
	public String getToolNo() {
		return toolNo;
	}
	public void setToolNo(String toolNo) {
		this.toolNo = toolNo;
	}
	public String getToolName() {
		return toolName;
	}
	public void setToolName(String toolName) {
		this.toolName = toolName;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public String getInvenType() {
		return invenType;
	}
	public void setInvenType(String invenType) {
		this.invenType = invenType;
	}
	@Override
	public String toString() {
		return "Item [toolNo=" + toolNo + ", toolName=" + toolName + ", quantity=" + quantity + ", itemType=" + itemType
				+ ", invenType=" + invenType + "]";
	}
	
	
}
