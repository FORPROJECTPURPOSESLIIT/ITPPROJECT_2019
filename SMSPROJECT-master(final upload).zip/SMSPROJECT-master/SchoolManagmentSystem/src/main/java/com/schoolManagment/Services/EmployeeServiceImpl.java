package com.schoolManagment.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.schoolManagment.DAO.EmployeeDAO;
import com.schoolManagment.Model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	EmployeeDAO empDao;
	
	@Autowired
	public void setEmpDao(EmployeeDAO empDao) {
		this.empDao = empDao;
	}


	public List<Employee> listAllEmployees() {
		return empDao.listAllEmployees();
	}

	
	public void addEmployees(Employee employee) {
		empDao.addEmployees(employee);
		
	}


	public void updateEmployees(Employee employee) {
		empDao.updateEmployees(employee);
	}

	
	public void deleteUser(String empId) {
		empDao.deleteUser(empId);
	}


	public Employee findEmployeeById(String empId) {
		return empDao.findEmployeeById(empId);
	}

}
