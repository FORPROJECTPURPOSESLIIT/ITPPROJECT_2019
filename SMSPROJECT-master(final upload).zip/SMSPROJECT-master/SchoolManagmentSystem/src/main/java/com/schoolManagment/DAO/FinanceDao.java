package com.schoolManagment.DAO;

import java.util.List;

import com.schoolManagment.Model.Finance;

public interface FinanceDao {


	public List<Finance> listAllFinance();
	
	
	
	public void addFinance(Finance finance);
	
	public void updateFinance(Finance finance);
	
	public void deleteFinance(String recordId);
	
	public Finance findFinanceByID(String recordId);
	
}
