 package com.schoolManagment.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.schoolManagment.Model.Transport;
import com.schoolManagment.Services.TransportService;
import com.schoolManagment.DAO.TransportDaoImpl;

@Controller
@RequestMapping(value="/transport")
public class TransportController {

	@Autowired
	TransportService transportService;
	
	@Autowired
	TransportDaoImpl transportDaoImpl;
	
	
	
	@RequestMapping(value="/list", method= RequestMethod.GET)
	public ModelAndView list() {
		
		 ModelAndView model = new  ModelAndView("transport/transport_list");
		
		 List<Transport> list = transportService.listAllTransport();
		 model.addObject("listTransport", list);
		 
		return model;
		
	}
	
	@RequestMapping(value="/add", method= RequestMethod.GET)
	public ModelAndView add() {
		
		 ModelAndView model = new  ModelAndView("transport/Transport");
		
		 Transport transport = new Transport();
		 model.addObject("transportForm", transport);
		 
		return model;
		
	}
	
	@RequestMapping(value="/update/{did}", method= RequestMethod.GET)
	public ModelAndView update(@PathVariable("did") String did) {
		
		 ModelAndView model = new  ModelAndView("transport/transport_form");
		
		 Transport transport = transportService.findTransportById(did);
		
		 model.addObject("transportForm", transport);
		
		 
		return model;
		
	}
	
	@RequestMapping(value="/save", method= RequestMethod.POST)
	public ModelAndView save(@ModelAttribute("transportForm") Transport transport) {
		
		 
		
		 if(transport != null && transport.getDid() != null) {
			 
			 //update
			 transportService.updateTransport(transport);
			 System.out.println("abc");
			 
		 }else {
			 //add new
			 transportService.addTransport(transport);
		
		 }
		 
		 return new ModelAndView("redirect:/transport/list");
		
		
	}
	
	@RequestMapping(value="/insert", method= RequestMethod.POST)
	public ModelAndView insert(@ModelAttribute("transportForm") Transport transport) {
		
		 
		
		 if(transport != null && transport.getDid() != null) {
			 
			 //update
			 transportService.addTransport(transport);
			 System.out.println("dcf");
			 
		 }
		 
		 return new ModelAndView("redirect:/transport/list");
		
		
	}
	
	@RequestMapping(value="/delete/{did}", method= RequestMethod.GET)
	public ModelAndView delete(@PathVariable("did") String did) {
		
		
		 transportService.deleteTransport(did);
		
		 return new ModelAndView("redirect:/transport/list");
		
	}

	@RequestMapping(value="/autoFill", method= RequestMethod.GET)
	public ModelAndView autoFill(Transport transport) {
		
		 ModelAndView model = new  ModelAndView("transport/Transport");
		 
		transport.setDid("987000787");
		transport.setDname("Navodya");
		transport.setVehicleID("Bus 1");
		transport.setDescription("Transport is provided from Kekirawa to polonnaruwa");
		transport.setDistance("70"); 
		transport.setTdate("2019-02-13");
		transport.setFee("250");
		
		//transportService.addTransport(transport);
		
		model.addObject("transportForm", transport);
		return model;
		
	}
	
	
}
