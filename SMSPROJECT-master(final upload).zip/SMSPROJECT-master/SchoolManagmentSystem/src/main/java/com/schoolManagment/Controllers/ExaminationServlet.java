package com.schoolManagment.Controllers;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.schoolManagment.Model.Student;
import com.schoolManagment.Services.ExaminationServiceInterface;
import com.schoolManagment.Services.ExaminationServicesImpl;

public class ExaminationServlet extends HttpServlet {
	public static int increment = 12; 
	public static int whereToGo = 0;
	public static int dataalreadyinDB = 0;

	private static final long serialVersionUID = 1L;
    public ExaminationServlet() {
        super();
       
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	
	Student student = new Student();
	ArrayList<Student> studentList;
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		final Logger logger = LoggerFactory.getLogger(ExaminationServlet.class);
		logger.info("Welcome **********************************************************************************************.");
		
//		String grade = request.getParameter("hiddenValue");
//		String subject = request.getParameter("hiddenValue1");
		
		String grade = null;
		String subject = null;
		String term = request.getParameter("TermSelect");
		
		logger.info(term);
		
		int valueToChange = 0;
		
		grade = (String) request.getParameter("hiddenValue");
		subject = (String) request.getParameter("hiddenValue1");

		
		logger.info("789789 " + valueToChange);
		logger.info("increment  " + increment);
		
		if(increment != 12 ) {
			grade = (String) request.getAttribute("hiddenValue");
			subject = (String) request.getAttribute("hiddenValue1");
			logger.info("789789 " + grade);
			logger.info("789789 " + subject);
		}
		
		student.setSubject(subject);
		student.setGrade(grade);
		
		logger.info("====================" + student.getGrade());
		logger.info("====================" + student.getSubject());
		
		ExaminationServiceInterface examination = new ExaminationServicesImpl();
		//logger.info("5555555" +  examination.getResults(student));
		
		
		
		studentList = examination.getResults(student);
		
		if(whereToGo == 4) {
			logger.info("in 4");
			studentList = examination.getAllStudentResultList(student);
		}
		
		if(whereToGo == 3) {
			logger.info("in 3");
			examination.deleteStudentResults(student);
			
		}
		
		
		int index = 0 ;
		
		try {
			index = studentList.get(0).getIndexNo();
			
		} catch (IndexOutOfBoundsException e) {
			logger.info("out of bound");
		}
		
		double avgTerm1 = 0, avgTerm2 = 0, avgTerm3 = 0, term1 = 0, term2, term3, totTerm1 = 0, totTerm2 = 0, totTerm3 = 0;
		int count = 0;
		String temp1 = null, temp2 = null, temp3 = null;
		
		
		
		logger.info("////index  " + index);
		try {
			for (Student std : studentList) {
				
				if(!std.getTerm1().matches("-?\\d+")) {
					temp1 = std.getTerm1();
					std.setTerm1("0");
				}
				else if(std.getTerm1().matches("-?\\d+")) {
					temp1 = std.getTerm1();
				}
				
				
				if(!std.getTerm2().matches("-?\\d+")) {
					temp2 = std.getTerm2();
					std.setTerm2("0");
				}
				else if(std.getTerm2().matches("-?\\d+")) {
					temp2 = std.getTerm2();
				}
				
				
				if(!std.getTerm3().matches("-?\\d+")) {
					temp3 = std.getTerm3();
					std.setTerm3("0");
				}
				else if(std.getTerm3().matches("-?\\d+")) {
					temp3 = std.getTerm3();
				}
								
				term1 = Double.parseDouble(std.getTerm1());
				term2 = Double.parseDouble(std.getTerm2());
				term3 = Double.parseDouble(std.getTerm3());
				
				totTerm1 = totTerm1 + term1;
				totTerm2 = totTerm2 + term2;
				totTerm3 = totTerm3 + term3;
				count++;
				
				std.setTerm1(temp1);
				std.setTerm2(temp2);
				std.setTerm3(temp3);
				
			}
			
			avgTerm1 = totTerm1 / count;
			avgTerm2 = totTerm2 / count;
			avgTerm3 = totTerm3 / count;
			
		} catch (NumberFormatException e) {
			logger.info("////NumberFormatException  ");
		}
		
		logger.info("////" + avgTerm1 + avgTerm2 + avgTerm3);

		
		
		request.setAttribute("grade", grade);
		request.setAttribute("subject", subject);
		request.setAttribute("classAverage1", avgTerm1);
		request.setAttribute("classAverage2", avgTerm2);
		request.setAttribute("classAverage3", avgTerm3);
		request.setAttribute("nOfStudents", count);
		request.setAttribute("studentList", studentList);
		request.setAttribute("TermSelect", term);
		
		if(whereToGo == 1) {
			//whereToGo = 0;
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Examination/viewMarks");
			dispatcher.forward(request, response);
		}else if(whereToGo == 2) {
			//whereToGo = 0;
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Examination/updateMarks");
			dispatcher.forward(request, response);
		}else if(whereToGo == 3) {
			//whereToGo = 0;
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/admin/result");
			dispatcher.forward(request, response);
		}else if(whereToGo == 4) {
			//whereToGo = 0;
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Examination/insertMarks");
			dispatcher.forward(request, response);
		}else if(whereToGo == 5) {
			//whereToGo = 0;
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Examination/insertMarks");
			dispatcher.forward(request, response);
		}
	}
	
	public String sendSubject() {
		return student.getSubject();
	}
	
	public String sendGrade() {
		return student.getGrade();
	}
	
	public ArrayList<Student> sendStudentList() {
		return studentList;
	}
	
}