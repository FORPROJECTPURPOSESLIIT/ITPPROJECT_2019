package com.schoolManagment.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ColumnMapRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;


import com.schoolManagment.Model.ParentDetails;
import com.schoolManagment.Model.Transport;

@Repository
public class ParentDetailsDaoImpl implements ParentDetailsDao {
	
     NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
@Autowired
	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) throws DataAccessException{
	
	this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
		

}
	
	@Override
	public List<ParentDetails> listAllParentDetails() {
		
        String sql = "SELECT parentId, pName, bday, occupation, conatctNo, indexNo FROM parentdetails";
		
		List<ParentDetails> list =  namedParameterJdbcTemplate.query(sql, getSqlParameterByModel(null), new ParentDetailsMapper());
		
		return list;
	}

    private SqlParameterSource getSqlParameterByModel(ParentDetails parentDetails) {
		
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		
	    if(parentDetails != null ) {
			
			paramSource.addValue("parentId", parentDetails.getParentId());
			paramSource.addValue("pName", parentDetails.getpName());
			paramSource.addValue("bday", parentDetails.getBday());
			paramSource.addValue("occupation", parentDetails.getOccupation());
			paramSource.addValue("conatctNo", parentDetails.getConatctNo());
			paramSource.addValue("indexNo", parentDetails.getIndexNo());
			
		}
		
		 return paramSource;
	}
    
    private static final class ParentDetailsMapper implements RowMapper<ParentDetails>{
		
		public ParentDetails mapRow(ResultSet rs, int rowNum) throws SQLException{
			
			ParentDetails parentDetails = new ParentDetails();
			parentDetails.setParentId(rs.getString("parentId"));
			parentDetails.setpName(rs.getString("pName"));
			parentDetails.setBday(rs.getString("bday"));
			parentDetails. setOccupation(rs.getString("occupation"));
			parentDetails.setConatctNo(rs.getString("conatctNo"));
			parentDetails.setIndexNo(rs.getString("indexNo"));
			
			return parentDetails;
		}
	}
	
	
	
	@Override
	public void addParentDetails(ParentDetails parentDetails) {
		
        String sql = "INSERT INTO parentdetails(parentId, pName, bday, occupation, conatctNo, indexNo) VALUES (:parentId, :pName, :bday, :occupation, :conatctNo, :indexNo)";
		
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(parentDetails));
		
		
	}

	@Override
	public void updateParentDetails(ParentDetails parentDetails) {
		
		
		String sql = "UPDATE parentdetails SET pName = :pName , bday = :bday , occupation = :occupation , conatctNo = :conatctNo, indexNo = :indexNo WHERE parentId = :parentId";
	
		namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(parentDetails));
	
		
	}

	@Override
	public void deleteParentDetails(String parentId) {
	
       String sql = "DELETE FROM parentdetails WHERE parentId = :parentId";
		
	   namedParameterJdbcTemplate.update(sql, getSqlParameterByModel(new ParentDetails(parentId)));
		
	}

	@Override
	public ParentDetails findParentDetailsById(String parentId) {
	
        String sql = "SELECT * FROM parentdetails WHERE parentId = :parentId";
		
		
		return namedParameterJdbcTemplate.queryForObject(sql, getSqlParameterByModel(new ParentDetails(parentId)), new ParentDetailsMapper());
		
	}

	@Override
	public List<ParentDetails> findParentDetails(String parentId, String txt) {
		// TODO Auto-generated method stub
		return null;
	}

	


}
