package com.schoolManagment.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.schoolManagment.DAO.StudentDAO;
import com.schoolManagment.Model.Student;
@Service
public class StudentServiceImpl implements StudentService{

	StudentDAO studentDao;
	
	@Autowired
	public void SetStudentDao(StudentDAO studentDao) {
		this.studentDao = studentDao;
	}
	
	
	@Override
	public List<Student> ListAllStudents() {
		
		return studentDao.listAllStudents();
	}

	@Override
	public void AddStudent(Student student) {
		
		studentDao.AddStudent(student);
		
	}

	@Override
	public void UpdateStudent(Student student) {
		
		studentDao.UpdateStudent(student);
		
	}

	@Override
	public void DeleteStudent(int indexNo) {
		
		studentDao.DeleteStudent(indexNo);
	}

	@Override
	public Student FindStudentById(int indexNo) {
		
		
		
		return studentDao.findStudentById(indexNo);
	}

}
