package com.schoolManagment.Services;

import java.util.List;

import com.schoolManagment.Model.Transport;

public interface TransportService {
	
	
		
		public List<Transport> listAllTransport();
		
		public void addTransport(Transport transport);
		
		public void updateTransport(Transport transport);
		
		public void deleteTransport(String did);
		
		public Transport findTransportById(String did);
		
		

	


}
