package com.schoolManagment.DAO;

import java.util.List;

import com.schoolManagment.Model.Item;

public interface ItemDao {

	public List<Item> listAllItems();
	
	public void addItem(Item item);
	
	public void updateItem(Item item);
	
	public void deteteItem(String toolNo);
	
	public Item findItemById(String toolNo);
	
	public List<Item> ListAllClassItems(String tooNo);
	
}
