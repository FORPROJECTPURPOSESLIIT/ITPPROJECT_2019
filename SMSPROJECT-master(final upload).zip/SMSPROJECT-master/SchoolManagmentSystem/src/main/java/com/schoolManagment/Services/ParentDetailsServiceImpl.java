package com.schoolManagment.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.schoolManagment.DAO.ParentDetailsDao;
import com.schoolManagment.Model.ParentDetails;

@Service
public class ParentDetailsServiceImpl implements ParentDetailsService{

	ParentDetailsDao parentDetailsDao;
	
	
	@Autowired
	public void setParentDetailsDao(ParentDetailsDao parentDetailsDao) {
		this.parentDetailsDao = parentDetailsDao;
	}

	@Override
	public List<ParentDetails> listAllParentDetails() {
		
		return parentDetailsDao.listAllParentDetails();
	}

	@Override
	public void addParentDetails(ParentDetails parentDetails) {
		
		parentDetailsDao.addParentDetails(parentDetails);
		
	}

	@Override
	public void updateParentDetails(ParentDetails parentDetails) {
		
		parentDetailsDao.updateParentDetails(parentDetails);
		
	}

	@Override
	public void deleteParentDetails(String parentId) {
		
		parentDetailsDao.deleteParentDetails(parentId);
		
	}

	@Override
	public ParentDetails findParentDetailsById(String parentId) {
		
		return parentDetailsDao.findParentDetailsById(parentId);
	}

}
