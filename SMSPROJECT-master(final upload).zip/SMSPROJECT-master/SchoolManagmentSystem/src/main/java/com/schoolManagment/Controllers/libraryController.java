package com.schoolManagment.Controllers;

import java.util.List;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.schoolManagment.DAO.LibraryDoaImpl;
import com.schoolManagment.Model.Library;
import com.schoolManagment.Services.LibrarySevice;
import com.schoolManagment.View.ExcelViewListReportView;
import com.schoolManagment.View.PdfViewListReportView;

@Controller
@RequestMapping(value = "/library")
public class libraryController {

	@Autowired
	LibrarySevice libraryService;

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {

		ModelAndView model = new ModelAndView("/library/libraryViewBooks");
		List<Library> list = libraryService.bookList();
		model.addObject("listBooks", list);

		return model;

	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView add() {

		ModelAndView model = new ModelAndView("/library/libraryAddBook");
		Library library = new Library();
		model.addObject("listaddBooks", library);

		return model;

	}

	@RequestMapping(value = "/update/{isbn}", method = RequestMethod.GET)
	public ModelAndView update(@PathVariable("isbn") String isbn) {

		ModelAndView model = new ModelAndView("/library/libraryUpdateBook");

		Library library = libraryService.findBookByID(isbn);
		model.addObject("listaddBooks", library);

		return model;

	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView save(@ModelAttribute("listaddBooks") Library library) {

		libraryService.addBookLibrary(library);

		return new ModelAndView("redirect:/library/list");

	}

	@RequestMapping(value = "/updateBook", method = RequestMethod.POST)
	public ModelAndView updateBook(@ModelAttribute("listaddBooks") Library library) {

		libraryService.updateBookLibrary(library);

		return new ModelAndView("redirect:/library/list");

	}

	@RequestMapping(value = "/delete/{isbn}", method = RequestMethod.GET)
	public ModelAndView delete(@PathVariable("isbn") String isbn) {
		libraryService.deleteBookLibrary(isbn);

		return new ModelAndView("redirect:/library/list");

	}

	@RequestMapping(value = "/issueBook", method = RequestMethod.GET)
	public ModelAndView issueBook() {

		ModelAndView model = new ModelAndView("/library/libraryIssueBooks");

		Library library = new Library();
		model.addObject("listissueBooks", library);

		return model;

	}

	@RequestMapping(value = "/issue/{isbn}", method = RequestMethod.GET)
	public ModelAndView issue(@PathVariable("isbn") String isbn) {

		ModelAndView model = new ModelAndView("/library/libraryIssueBooks");

		Library library = libraryService.findBookByID(isbn);
		model.addObject("listissueBooks", library);

		return model;
		
	}
	
//	@RequestMapping(value = "/issueviewpdateBook", method = RequestMethod.POST)
//	public ModelAndView issueviewupdateBook(@ModelAttribute("listissueBooks") Library library) {
//
//		libraryService.issueBookLibrary(library);
//
//		return new ModelAndView("redirect:/library/issuelist");
//
//	}


	@RequestMapping(value = "/issuelist", method = RequestMethod.GET)
	public ModelAndView issuelist() {

		ModelAndView model = new ModelAndView("/library/viewIssuedBooks");

		List<Library> issuelist = libraryService.issueBookList();
		model.addObject("listIssue", issuelist);

		return model;

	}

	@RequestMapping(value = "/saveIssue", method = RequestMethod.POST)
	public ModelAndView saveIssue(@ModelAttribute("listissueBooks") Library library) {
		
	System.out.println("save issue function" + library);
		libraryService.issueBookLibrary(library);

		return new ModelAndView("redirect:/library/issuelist");

	}

	@RequestMapping(value = "/viewlist", method = RequestMethod.GET)
	public ModelAndView viewlist() {

		ModelAndView model = new ModelAndView("/library/viewBooksUsers");

		List<Library> viewlist = libraryService.viewBookListUsers();
		model.addObject("listViews", viewlist);

		return model;

	}
	
	//search function
	
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView SearchBooks(@ModelAttribute("listBooks")Library library) {
		
		String isbn = library.getIsbn();
		
		Library searchlist = libraryService.findBookByID(isbn);
		ModelAndView model = new ModelAndView("/library/Search");
		model.addObject("searchResult", searchlist);		
		return model;		
	}

	@RequestMapping(value = "/updateIssueDetails", method = RequestMethod.GET)
	public ModelAndView UpdateIssueDetails(@ModelAttribute("listBooks")Library library) {
		
		String isbn = library.getIsbn();		
		
		Library l = libraryService.findBookByID(isbn);
		library.setBname(l.getBname());
		library.setAuthor(l.getAuthor());			
		libraryService.issueBookLibrary(library);
		
		
		//Just have to send the library object to database
		return new ModelAndView("redirect:/library/issuelist");
		
		}
//...............report generating function...........................................................................
	
	@RequestMapping(value="/report", method=RequestMethod.GET)
	public ModelAndView libraryViewBooks(HttpServletRequest req, HttpServletResponse res) {
		
		String typeReport =  req.getParameter("type");
		
		List<Library> list = libraryService.bookList();
		
		if(typeReport != null && typeReport.equals("xls")) {
			
			return new ModelAndView(new ExcelViewListReportView(), "viewlist", list);
		
		}else if(typeReport != null && typeReport.equals("pdf")){
			
			return new ModelAndView(new PdfViewListReportView(), "viewlist", list);
		}
		
		return new ModelAndView("libraryViewBooks","viewlist" ,list);
	}
	
}