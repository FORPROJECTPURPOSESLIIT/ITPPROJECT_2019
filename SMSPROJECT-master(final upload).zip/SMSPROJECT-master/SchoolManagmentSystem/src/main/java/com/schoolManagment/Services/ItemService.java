package com.schoolManagment.Services;

import java.util.List;

import com.schoolManagment.Model.Item;


public interface ItemService {

	public List<Item> ListAllItems();
	
	public void addItems (Item item);
	
	public void updateItems(Item item);
	
	public void deleteItems(String toolNo);
	
	public Item findItemById(String toolNo);
	
	public List<Item> ListAllClassItems(String tooNo);
	
}
