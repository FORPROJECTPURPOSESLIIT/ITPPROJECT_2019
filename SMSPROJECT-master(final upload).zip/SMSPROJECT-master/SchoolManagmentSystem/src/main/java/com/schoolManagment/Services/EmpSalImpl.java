package com.schoolManagment.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.schoolManagment.DAO.EmpsalDao;
import com.schoolManagment.DAO.UserDao;
import com.schoolManagment.Model.EmpSal;


@Service
public class EmpSalImpl implements EmpSalService{

	EmpsalDao empsalDao;
	
	
	
	
	@Autowired
	public void setEmpsalDao(EmpsalDao empsalDao) {
		this.empsalDao = empsalDao;
	}


	public List<EmpSal> listAllEmpSal() {
		return empsalDao.listAllEmpSal();
	}

	
	public void addEmpSal(EmpSal empsal) {
		empsalDao.addEmpSal(empsal);		
	}

	
	public void updateEmpSal(EmpSal empsal) {
		empsalDao.updateEmpSal(empsal);
	}

	
	public void deleteEmpSal(String empId) {
		empsalDao.deleteEmpSal(empId);		
	}

	
	public EmpSal findEmpSalById(String empId) {
		return empsalDao.findEmpSalById(empId);
	}

}
