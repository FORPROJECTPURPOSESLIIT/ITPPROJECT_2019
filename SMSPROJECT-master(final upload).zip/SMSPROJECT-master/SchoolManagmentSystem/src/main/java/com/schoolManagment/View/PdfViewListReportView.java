package com.schoolManagment.View;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Document;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.PdfWriter;
import com.schoolManagment.Model.Library;

public class PdfViewListReportView extends AbstractPdfView{

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		response.setHeader("Content-Disposition", "attachment: filename=\"view_list.pdf\"");
		
		@SuppressWarnings("unchecked")
		List<Library> list = (List<Library>) model.get("viewlist");
		
		Table table = new Table(3);
		table.addCell("ISBN");
		table.addCell("BOOK NAME");
		table.addCell("AUTHOR");
		
		for(Library library : list) {
			
			table.addCell(library.getIsbn());
			table.addCell(library.getBname());
			table.addCell(library.getAuthor());
		}
		
		document.add(table);
		
	}

}
